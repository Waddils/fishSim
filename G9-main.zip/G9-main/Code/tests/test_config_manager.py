import sys
import os
import unittest
from unittest.mock import *
import json
import tempfile

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from config_manager import Config_Manager

class TestConfigManager(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.config_manager = Config_Manager()
        self.sample_data = {
            "boids": [{"x": 100, "y": 200}],
            "settings": {"speed": 1.5}
        }
    
    def test_save_config(self):
        # Mock file dialog to use temp directory
        with patch('tkinter.filedialog.asksaveasfilename') as mock_save:
            test_path = os.path.join(self.temp_dir.name, "test_config.json")
            mock_save.return_value = test_path
            
            # Test saving
            self.config_manager.save_config(self.sample_data)
            
            # Verify file exists
            self.assertTrue(os.path.exists(test_path))
            
            # Verify file content
            with open(test_path, 'r') as f:
                loaded_data = json.load(f)
            self.assertEqual(loaded_data, self.sample_data)

    def test_load_config(self):
        # First save a test file
        test_path = os.path.join(self.temp_dir.name, "load_test.json")
        with open(test_path, 'w') as f:
            json.dump(self.sample_data, f)
        
        # Mock file dialog to return our test path
        with patch('tkinter.filedialog.askopenfilename') as mock_open:
            mock_open.return_value = test_path
            
            # Test loading
            data, err_msg = self.config_manager.load_config()
            
            # Verify data matches
            self.assertIsNone(err_msg)
            self.assertEqual(data["boids"], self.sample_data["boids"])
            self.assertEqual(data["settings"], self.sample_data["settings"])
    
    def test_load_config_json_decode_error(self):
        # Create a file with invalid JSON
        test_path = os.path.join(self.temp_dir.name, "invalid_json.json")
        with open(test_path, 'w') as f:
            f.write("{invalid json: this is not proper json format}")
        
        # Mock file dialog to return our invalid JSON file
        with patch('tkinter.filedialog.askopenfilename') as mock_open:
            mock_open.return_value = test_path
            
            data, err_msg = self.config_manager.load_config()
            
            # Verify error handling
            self.assertIsNone(data)
            self.assertTrue("Invalid JSON format" in err_msg)

    def test_load_config_file_not_found(self):
        # Create a path that doesn't exist
        test_path = os.path.join(self.temp_dir.name, "nonexistent_file.json")
        
        # Mock file dialog to return our nonexistent file
        with patch('tkinter.filedialog.askopenfilename') as mock_open:
            mock_open.return_value = test_path
            
            # Simulate FileNotFoundError by removing permission or deleting file
            if os.path.exists(test_path):
                os.remove(test_path)  # Ensure the file doesn't exist
                
            # Should trigger FileNotFoundError
            data, err_msg = self.config_manager.load_config()
            
            # Verify error handling
            self.assertIsNone(data)
            self.assertTrue("File not found" in err_msg)
    
    def test_load_config_general_exception(self):
        # Create a valid path for mocking
        test_path = os.path.join(self.temp_dir.name, "exception_test.json")
        
        # Mock file dialog
        with patch('tkinter.filedialog.askopenfilename') as mock_open:
            mock_open.return_value = test_path
            
            # Mock open to raise a general exception
            with patch('builtins.open', side_effect=PermissionError("Access denied")):
                # Test loading should trigger general Exception
                data, err_msg = self.config_manager.load_config()
                
                # Verify error handling
                self.assertIsNone(data)
                self.assertTrue("Access denied" in err_msg)

    def tearDown(self):
        self.temp_dir.cleanup()

if __name__ == '__main__':
    unittest.main()