import math
import unittest
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from boid import Boid
from obstacle import Obstacle

class TestBoid(unittest.TestCase):
    def setUp(self):
        self.boid = Boid(x=100, y=100, vel_x=1, vel_y=1)
        self.screen_width = 800
        self.screen_height = 600
        self.obstacle = Obstacle(200, 200, 30)
        
        # Flocking parameters from boid.py
        self.expected_params = {
            'max_speed': 3.0,
            'max_force': 0.8,
            'separation_radius': 25,
            'neighbor_radius': 50,
            'inertia_factor': 0.75
        }

    def test_init(self):
        # Test position and velocity
        self.assertEqual(self.boid.x, 100)
        self.assertEqual(self.boid.y, 100)
        self.assertEqual(self.boid.vel_x, 1)
        self.assertEqual(self.boid.vel_y, 1)
        
        # Test parameter initialization
        for param, value in self.expected_params.items():
            self.assertEqual(getattr(self.boid, param), value)

    def test_movement(self):
        original_x = self.boid.x
        original_y = self.boid.y
        self.boid.update()
        self.assertEqual(self.boid.x, original_x + self.boid.vel_x)
        self.assertEqual(self.boid.y, original_y + self.boid.vel_y)

    def test_boundary_avoidance(self):
        # Test all four boundaries with margin
        test_cases = [
            (self.screen_width - 20, 300, "x"),  # Right boundary margin
            (20, 300, "x"),                      # Left boundary margin
            (400, self.screen_height - 20, "y"),  # Bottom margin
            (400, 50, "y")                        # Top margin (with boundary_top=28)
        ]
        
        for x, y, axis in test_cases:
            self.boid.x = x
            self.boid.y = y
            original_vel = getattr(self.boid, f"vel_{axis}")
            
            self.boid.check_boundaries(self.screen_width, self.screen_height, boundary_top=28)
            
            new_vel = getattr(self.boid, f"vel_{axis}")
            self.assertNotEqual(new_vel, original_vel)
            self.assertTrue(abs(new_vel) <= self.boid.max_speed)

    def test_obstacle_avoidance(self):
        # Create obstacle close to boid
        close_obstacle = Obstacle(self.boid.x + 35, self.boid.y, 30)
        original_vel = (self.boid.vel_x, self.boid.vel_y)
        
        steering = self.boid.avoid_obstacles([close_obstacle])
        self.assertNotEqual(steering, (0, 0))
        
        # Verify velocity changed and limited
        self.assertNotEqual(self.boid.vel_x, original_vel[0])
        self.assertNotEqual(self.boid.vel_y, original_vel[1])
        self.assertTrue(math.hypot(self.boid.vel_x, self.boid.vel_y) <= self.boid.max_speed)

    def test_collision_resolution(self):
        # Place boid inside obstacle
        self.boid.x = self.obstacle.x
        self.boid.y = self.obstacle.y
        self.assertTrue(self.obstacle.contains(self.boid.x, self.boid.y))
        
        self.boid.resolve_collision([self.obstacle])
        self.assertFalse(self.obstacle.contains(self.boid.x, self.boid.y))

    def test_flocking_forces(self):
        # Create neighboring boids
        neighbors = [
            Boid(self.boid.x + 20, self.boid.y, 1, 1),
            Boid(self.boid.x - 20, self.boid.y, -1, 1),
            Boid(self.boid.x, self.boid.y + 20, 1, -1)
        ]
        
        # Test alignment
        align = self.boid.calculate_alignment(neighbors)
        self.assertNotEqual(align, (0, 0))
        
        # Test cohesion
        cohere = self.boid.calculate_cohesion(neighbors)
        self.assertNotEqual(cohere, (0, 0))
        
        # Test separation
        separate = self.boid.calculate_separation(neighbors)
        self.assertNotEqual(separate, (0, 0))

    def test_force_application(self):
        original_speed = math.hypot(self.boid.vel_x, self.boid.vel_y)
        test_force = (2.0, 1.5)
        
        self.boid.apply_force(*test_force, weight=1.0)
        new_speed = math.hypot(self.boid.vel_x, self.boid.vel_y)
        
        # Verify speed changed and within limits
        self.assertNotAlmostEqual(new_speed, original_speed)
        self.assertTrue(new_speed <= self.boid.max_speed)

    def test_speed_limiting(self):
        # Exceed max speed
        self.boid.vel_x = 5.0
        self.boid.vel_y = 5.0
        self.boid.limit_speed()
        
        speed = math.hypot(self.boid.vel_x, self.boid.vel_y)
        self.assertAlmostEqual(speed, self.boid.max_speed, delta=0.1)

    def test_edge_cases(self):
        # Test zero velocity
        self.boid.vel_x = 0
        self.boid.vel_y = 0
        self.boid.update()
        self.assertEqual(self.boid.x, 100)
        self.assertEqual(self.boid.y, 100)
        
        # Test maximum force application with speed limiting
        large_force = (10.0, 10.0)
        self.boid.apply_force(*large_force, weight=1.0)
        self.boid.limit_speed()  # Explicitly enforce speed limit
        speed = math.hypot(self.boid.vel_x, self.boid.vel_y)
        self.assertAlmostEqual(speed, self.boid.max_speed, delta=0.1)

    def tearDown(self):
        return super().tearDown()

if __name__ == '__main__':
    unittest.main()