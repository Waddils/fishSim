import unittest
from unittest.mock import patch, MagicMock
import random
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from food import Food

class TestFood(unittest.TestCase):
    def setUp(self):
        """
        Set up test fixtures before each test method.
        """
        # Create a basic food object for testing
        self.food = Food(100, 200, 5, 20)
        
        # Mock obstacle for collision testing
        self.mock_obstacle = MagicMock()
        self.mock_obstacle.x = 110
        self.mock_obstacle.y = 210
        self.mock_obstacle.radius = 10

    def test_init_valid_parameters(self):
        """
        Test successful initialization with valid parameters.
        """
        food = Food(100, 200, 5, 20)
        self.assertEqual(food.x, 100.0)
        self.assertEqual(food.y, 200.0)
        self.assertEqual(food.size, 5.0)
        self.assertEqual(food.decay_time, 20)

    def test_init_default_decay_time(self):
        """
        Test initialization with default random decay time.
        """
        with patch('random.randint', return_value=25):
            food = Food(100, 200, 5)
            self.assertEqual(food.decay_time, 25)

    def test_init_invalid_size(self):
        """
        Test initialization with invalid size parameter.
        """
        with self.assertRaises(Exception):
            Food(100, 200, 0)  # Size cannot be zero or negative

    def test_init_invalid_type(self):
        """
        Test initialization with invalid parameter types.
        """
        with self.assertRaises(Exception):
            Food("not_a_number", 200, 5)

    def test_collides_with_obstacle_collision(self):
        """
        Test collision detection with an obstacle that causes collision.
        """
        obstacles = [self.mock_obstacle]
        # Food at (100, 200) with size 5 and obstacle at (110, 210) with radius 10
        # Distance = sqrt((110-100)^2 + (210-200)^2) = sqrt(200) = 14.14...
        # Combined radii with buffer = 5 + 10 + 3 = 18
        # Since distance < combined radii, should detect collision
        self.assertTrue(self.food.collides_with_obstacle(obstacles))

    def test_collides_with_obstacle_no_collision(self):
        """
        Test collision detection with an obstacle that doesn't cause collision.
        """
        far_obstacle = MagicMock()
        far_obstacle.x = 150
        far_obstacle.y = 250
        far_obstacle.radius = 10
        obstacles = [far_obstacle]
        # Distance = sqrt((150-100)^2 + (250-200)^2) = sqrt(5000) = 70.71...
        # Combined radii with buffer = 5 + 10 + 3 = 18
        # Since distance > combined radii, should not detect collision
        self.assertFalse(self.food.collides_with_obstacle(obstacles))

    def test_collides_with_obstacle_error_handling(self):
        """
        Test error handling in collision detection.
        """
        invalid_obstacle = MagicMock()
        # Missing radius attribute will cause an exception
        invalid_obstacle.x = 110
        invalid_obstacle.y = 210
        
        with self.assertRaises(Exception):
            self.food.collides_with_obstacle([invalid_obstacle])

    @patch('random.randint')
    def test_spawn_random_no_obstacles(self, mock_randint):
        """
        Test random food spawning with no obstacles.
        """
        mock_randint.side_effect = [100, 200, 25]  # x, y, decay_time
        food = Food.spawn_random(800, 600)
        self.assertEqual(food.x, 100)
        self.assertEqual(food.y, 200)
        self.assertEqual(food.size, 5)

    @patch('random.randint')
    def test_spawn_random_with_boundary_top(self, mock_randint):
        """
        Test random food spawning with top boundary offset.
        """
        mock_randint.side_effect = [100, 200, 25]  # x, y, decay_time
        food = Food.spawn_random(800, 600, boundary_top=50)
        self.assertEqual(food.x, 100)
        self.assertEqual(food.y, 200)
        mock_randint.assert_any_call(5, 845)
        mock_randint.assert_any_call(55, 645)

    @patch('random.randint')
    def test_spawn_random_with_obstacles_avoid_collision(self, mock_randint):
        """
        Test random food spawning with obstacle avoidance.
        """
        # First attempt has collision, second attempt is successful
        mock_randint.side_effect = [100, 200, 25, 300, 400, 30]  # Two iterations
        obstacle = MagicMock()
        obstacle.x = 100
        obstacle.y = 200
        obstacle.radius = 10
        
        with patch.object(Food, 'collides_with_obstacle', side_effect=[True, False]):
            food = Food.spawn_random(800, 600, [obstacle])
            self.assertEqual(food.x, 300)
            self.assertEqual(food.y, 400)

    def test_decay_not_expired(self):
        """
        Test decay behavior when food has not yet expired.
        """
        food = Food(100, 200, 5, 20)
        # Food should not decay after 5 time units
        self.assertFalse(food.decay(5))
        self.assertEqual(food.decay_time, 15)  # 20 - 5 = 15

    def test_decay_expired(self):
        """
        Test decay behavior when food expires.
        """
        food = Food(100, 200, 5, 20)
        # Food should decay after 25 time units (more than decay_time)
        self.assertTrue(food.decay(25))
        self.assertEqual(food.decay_time, -5)  # 20 - 25 = -5

    def test_decay_exact_expiration(self):
        """
        Test decay behavior when food expires exactly at decay_time.
        """
        food = Food(100, 200, 5, 20)
        self.assertTrue(food.decay(20))
        self.assertEqual(food.decay_time, 0)


if __name__ == '__main__':
    unittest.main()