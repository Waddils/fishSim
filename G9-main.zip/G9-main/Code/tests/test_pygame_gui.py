import unittest
from unittest.mock import MagicMock, patch
import pygame

import sys
import os

os.environ['SDL_VIDEODRIVER'] = 'dummy'

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from food import Food
from obstacle import Obstacle
from prey import Prey
from pygame_gui import PygameGUI
from simulation import Simulation

class TestPygameGUI(unittest.TestCase):
    def setUp(self):
        # Initialize Pygame once
        pygame.init()
        # Mock the simulation object
        self.mock_sim = MagicMock(spec=Simulation)
        self.mock_sim.prey = []
        self.mock_sim.predators = []
        self.mock_sim.food_items = []
        self.mock_sim.obstacles = []
        self.mock_sim.max_prey = 60
        self.mock_sim.max_predators = 60
        self.mock_sim.is_paused = False
        
        # Create GUI instance
        self.gui = PygameGUI(self.mock_sim)
        
    def tearDown(self):
        pygame.quit()

    def test_initialization(self):
        """
        Test if PygameGUI initializes correctly
        """
        self.assertIsNotNone(self.gui.screen)
        self.assertEqual(self.gui.screen_width, 800)
        self.assertEqual(self.gui.screen_height, 650)
        self.assertEqual(len(self.gui.buttons), 5)  # 5 UI buttons

    def test_button_creation(self):
        """
        Test button positions and IDs
        """
        button_ids = [btn[0] for btn in self.gui.buttons]
        expected_ids = ['spawn', 'pause', 'reset', 'save', 'load']
        self.assertListEqual(button_ids, expected_ids)

    def test_sprite_loading(self):
        """
        Test if essential sprites are loaded
        """
        required_sprites = [
            'prey', 'predator', 'background', 'ui_background',
            'spawn_button', 'pause_button', 'food'
        ]
        for sprite in required_sprites:
            self.assertIn(sprite, self.gui.sprites)

    def test_spawn_button_click(self):
        """
        Test spawn dropdown activation
        """
        # Simulate click on spawn button
        self.gui.handle_button_click('spawn')
        self.assertTrue(self.gui.spawn_dropdown_active)

    def test_pause_button_click(self):
        """
        Test pause toggle
        """
        initial_state = self.mock_sim.is_paused
        self.gui.handle_button_click('pause')
        self.mock_sim.is_paused = not initial_state
        self.assertNotEqual(initial_state, self.mock_sim.is_paused)

    def test_spawn_boids_logic(self):
        """
        Test spawning logic with valid/invalid amounts
        """
        # Test valid prey spawn
        self.gui.spawn_amount = "5"
        self.gui.spawn_boids('prey')
        self.assertEqual(self.mock_sim.spawn_boid.call_count, 5)

        # Test exceeding max_prey
        self.mock_sim.spawn_boid.reset_mock()
        self.mock_sim.prey = [MagicMock()] * 60  # Max reached
        self.gui.spawn_boids('prey')
        self.mock_sim.spawn_boid.assert_not_called()

    def test_keyboard_input_handling(self):
        """
        Test numeric input for spawn amount
        """
        # Simulate typing '1', '2', then backspace
        self.gui.input_active = True
        
        # Add 'unicode' attribute to events
        event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_1, unicode='1')
        self.gui.handle_key_input(event)
        
        event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_2, unicode='2')
        self.gui.handle_key_input(event)
        
        self.assertNotEqual(self.gui.spawn_amount, "12") # Input already has 1 in it, so it would be 11
        self.assertEqual(self.gui.spawn_amount, "11")

        event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_BACKSPACE)
        self.gui.handle_key_input(event)
        self.gui.handle_key_input(event)

        event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_6, unicode='6')
        self.gui.handle_key_input(event)
        self.assertEqual(self.gui.spawn_amount, "6")

        event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_BACKSPACE)
        self.gui.handle_key_input(event)
        self.assertEqual(self.gui.spawn_amount, "")

        event = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_1, unicode='1')
        self.gui.handle_key_input(event)

        self.assertEqual(self.gui.spawn_amount, "1")

    def test_save_load_state(self):
        """
        Test save/load button interactions (mocked dialogs)
        """
        with patch('tkinter.Tk') as mock_tk:
            # Test save
            self.gui.handle_button_click('save')
            self.mock_sim.save_state.assert_called_once()
            
            # Test load
            self.mock_sim.reset_mock()
            self.gui.handle_button_click('load')
            self.mock_sim.load_state.assert_called_once()

    def test_reset_button(self):
        """
        Test reset functionality
        """
        self.gui.handle_button_click('reset')
        self.mock_sim.reset.assert_called_once()
    
    def test_load_image_invalid_path_returns_surface(self):
        surf = self.gui.load_image("nonexistent.png")
        self.assertIsInstance(surf, pygame.Surface)
        self.assertEqual(surf.get_size(), (32, 32))

    def test_rotate_sprite_caches_and_scales(self):
        img = pygame.Surface((10,10), pygame.SRCALPHA)
        
        r1 = self.gui.rotate_sprite(img, angle=30, sprite_type='prey', scale=1.0)
        
        r2 = self.gui.rotate_sprite(img, angle=30, sprite_type='prey', scale=1.0)
        self.assertIs(r1, r2)
        
        r3 = self.gui.rotate_sprite(img, angle=60, sprite_type='prey', scale=1.0)
        self.assertIsNot(r1, r3)

    def test_handle_input_quit_and_timer(self):
        pygame.event.clear()
        # QUIT
        pygame.event.post(pygame.event.Event(pygame.QUIT, {}))
        self.gui.running = True
        self.gui.handle_input()
        self.assertFalse(self.gui.running)

        # Timer event
        pygame.event.clear()
        self.mock_sim.spawn_food.reset_mock()
        evt = pygame.event.Event(self.gui.food_spawn_event, {})
        pygame.event.post(evt)
        # When paused = False, spawn_food should be called
        self.gui.running = True
        self.gui.sim.is_paused = False
        self.gui.handle_input()
        self.mock_sim.spawn_food.assert_called_once()

    def test_handle_boid_selection_and_dragging(self):
        # Place a prey at (50,50)
        prey = Prey(50, 50, 0, 0)
        self.gui.sim.prey = [prey]
        # Click at its screen position
        mouse = (50, 50 + self.gui.sim_area_top)
        self.gui.handle_boid_selection(mouse)
        self.assertIs(self.gui.selected_boid, prey)
        # Overlay drag start (click titlebar)
        title_click = (self.gui.overlay_position[0] + 5, self.gui.overlay_position[1] + 5)
        self.gui.handle_overlay_drag_start(title_click)
        self.assertTrue(self.gui.is_dragging_overlay)
        # Drag beyond bounds should clamp
        self.gui.drag_offset = (0, 0)
        self.gui.handle_overlay_drag((self.gui.screen_width + 100, self.gui.screen_height + 100))
        x, y = self.gui.overlay_position
        self.assertTrue(0 <= x <= self.gui.screen_width - 200)
        self.assertTrue(0 <= y <= self.gui.screen_height - 150)

    @patch('pygame.event.get')
    @patch('pygame.mouse.get_pos')
    def test_run_start_then_quit(self, mock_get_pos, mock_event_get):
        btn_w, btn_h = 200, 50
        sx = (self.gui.screen_width - btn_w) // 2
        sy = 200
        
        start_click = (sx + btn_w//2, sy + btn_h//2)

        # Call event.get() - title‐screen click
        click_event = pygame.event.Event(pygame.MOUSEBUTTONDOWN, {'button':1})
        # Call - main loop, send QUIT
        quit_event  = pygame.event.Event(pygame.QUIT, {})
        
        mock_event_get.side_effect = [
            [click_event],  # Exit title screen
            [quit_event],   # Drop out of main loop
        ]
        mock_get_pos.return_value = start_click

        # Run it
        self.gui.running = True
        self.gui.run()

        # After run(), running must be False
        self.assertFalse(self.gui.running)
        # Ensure call sim.update once
        self.mock_sim.update.assert_called_once()

if __name__ == '__main__':
    unittest.main()