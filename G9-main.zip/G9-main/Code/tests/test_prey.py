import unittest
from unittest.mock import MagicMock
import math

import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from prey import Prey

class TestPrey(unittest.TestCase):
    def setUp(self):
        self.prey = Prey(100, 200, 1.5, -2.0)
        self.predator_mock = MagicMock()
        self.predator_mock.x = 110
        self.predator_mock.y = 210
        self.food_mock = MagicMock()
        self.food_mock.x = 150
        self.food_mock.y = 250

    def test_initialization(self):
        self.assertEqual(self.prey.hunger, 94.0)
        self.assertEqual(self.prey.predator_avoidance_weight, 2.0)
        self.assertEqual(self.prey.max_speed, 5.0)

    def test_avoid_predators(self):
        steering = self.prey.avoid_predators([self.predator_mock])
        
        away_dx = self.prey.x - self.predator_mock.x
        away_dy = self.prey.y - self.predator_mock.y
        
        dot = steering[0] * away_dx + steering[1] * away_dy
        self.assertGreater(dot, 0, "Steering should point away from the predator.")

    def test_hide_behind_obstacles(self):
        obstacle_mock = MagicMock()
        obstacle_mock.x = 200
        obstacle_mock.y = 300
        obstacle_mock.radius = 20

        # Adjust predator so that it is within detection range
        predator = MagicMock()
        predator.x = 110  # Changed to be within range
        predator.y = 210  # Changed to be within range
        steering = self.prey.hide_behind_obstacles([obstacle_mock], [predator])
        self.assertNotEqual(steering, (0, 0), "Hiding steering should not be zero when a predator is nearby.")

    def test_food_consumption(self):
        food_list = [self.food_mock]

        # Position prey near food
        self.prey.x = 150
        self.prey.y = 250
        self.assertTrue(self.prey.check_food_collision(self.food_mock))
        self.prey.consume_food(self.food_mock, food_list)
        
        # Since the hunger increase is capped at 100, we expect a final hunger of 100.
        self.assertEqual(self.prey.hunger, 100.0)
        self.assertNotIn(self.food_mock, food_list)

    def test_seek_closest_food(self):
        food_mock2 = MagicMock()
        food_mock2.x = 50
        food_mock2.y = 50
        
        steering = self.prey.seek_closest_food([self.food_mock, food_mock2], smoothing_factor=1.0)
        dx = self.food_mock.x - self.prey.x
        dy = self.food_mock.y - self.prey.y
        distance = math.sqrt(dx**2 + dy**2)
        expected_x = (dx / distance) * self.prey.max_speed - self.prey.vel_x
        expected_y = (dy / distance) * self.prey.max_speed - self.prey.vel_y
        self.assertAlmostEqual(steering[0], expected_x, delta=0.1)
        self.assertAlmostEqual(steering[1], expected_y, delta=0.1)

if __name__ == '__main__':
    unittest.main()