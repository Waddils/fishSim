import math
import random
import unittest
import sys
import os
from unittest.mock import patch

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from food import Food
from simulation import Simulation
from obstacle import Obstacle
from prey import Prey
from predator import Predator

class TestSimulation(unittest.TestCase):
    def setUp(self):
        self.sim = Simulation()
        self.sim.obstacles = []  # Clear default obstacles for controlled testing
        self.sim.boundary_top = 28

    def test_spawn_prey(self):
        initial_count = len(self.sim.prey)
        success = self.sim.spawn_boid("prey", 50, 50)
        self.assertTrue(success)
        self.assertEqual(len(self.sim.prey), initial_count + 1)

    def test_spawn_predator(self):
        success = self.sim.spawn_boid("predator", 100, 100)
        self.assertTrue(success)
        self.assertEqual(len(self.sim.predators), 1)

    def test_spawn_position_validation(self):
        # Test valid position
        self.assertTrue(self.sim.spawn_boid("prey", 50, 50))
        
        # Test invalid position inside obstacle
        obstacle = Obstacle(200, 200, 30)
        self.sim.obstacles.append(obstacle)
        self.assertFalse(self.sim.spawn_boid("prey", 200, 200))

    def test_population_limits(self):
        # Fill prey to max capacity
        for _ in range(self.sim.max_prey):
            self.sim.spawn_boid("prey")
            
        # Test over limit
        success = self.sim.spawn_boid("prey")
        self.assertFalse(success)
        self.assertEqual(len(self.sim.prey), self.sim.max_prey)

    def test_random_spawn_retries(self):
        # Create full coverage obstacle
        big_obstacle = Obstacle(
            x=self.sim.screen_width//2,
            y=self.sim.screen_height//2,
            radius=300  # Reduced radius to allow valid positions
        )
        self.sim.obstacles = [big_obstacle]

        with patch('random.randint') as mock_rand:
            # Simulate 5 failed attempts then valid position
            mock_rand.side_effect = [
                # 5 invalid attempts (center positions)
                self.sim.screen_width//2, self.sim.screen_height//2,
                self.sim.screen_width//2, self.sim.screen_height//2,
                self.sim.screen_width//2, self.sim.screen_height//2,
                self.sim.screen_width//2, self.sim.screen_height//2,
                self.sim.screen_width//2, self.sim.screen_height//2,
                # Valid position (edge of screen)
                50, 50
            ]
            success = self.sim.spawn_boid("prey", max_attempts=10)
            self.assertTrue(success)
            self.assertEqual(len(self.sim.prey), 1)

    def test_simulation_state_management(self):
        # Test pause/resume
        self.sim.pause()
        self.assertTrue(self.sim.is_paused)
        self.sim.resume()
        self.assertFalse(self.sim.is_paused)

        # Test reset
        self.sim.spawn_boid("prey")
        self.sim.spawn_boid("predator")
        self.sim.reset()
        self.assertEqual(len(self.sim.prey), 0)
        self.assertEqual(len(self.sim.predators), 0)
        self.assertEqual(len(self.sim.obstacles), 10)  # Default obstacle count

    def test_save_load_integrity(self):
        # Create test state
        self.sim.spawn_boid("prey", 100, 100)
        self.sim.spawn_boid("predator", 200, 200)
        original_prey = self.sim.prey[0]
        original_predator = self.sim.predators[0]

        # Save state
        saved_state = self.sim.save_state()

        # Modify state
        self.sim.spawn_boid("prey")
        self.sim.load_state(saved_state)

        # Verify loaded state
        self.assertEqual(len(self.sim.prey), 1)
        self.assertEqual(len(self.sim.predators), 1)
        
        loaded_prey = self.sim.prey[0]
        self.assertEqual(loaded_prey.x, original_prey.x)
        self.assertEqual(loaded_prey.hunger, original_prey.hunger)
        
        loaded_predator = self.sim.predators[0]
        self.assertEqual(loaded_predator.attack_range, original_predator.attack_range)

    def test_hunting_mechanics(self):
        # Setup predator and prey
        prey = Prey(110, 110, 0, 0)
        predator = Predator(100, 100, 1, 1)
        predator.attack_range = 50
        predator.aggression = 100
        self.sim.prey.append(prey)
        self.sim.predators.append(predator)

        prey.is_being_eaten = True
        prey.is_dead = True
        prey.death_timer = 0.03
        
        # Process death timer
        self.sim.manage_health_and_hunger()
        
        # Verify prey is removed after death timer expires
        self.assertEqual(len(self.sim.prey), 0)
    
    def test_health_and_hunger_mechanics(self):
        # Set up prey with low health
        prey = Prey(100, 100, 0, 0)
        prey.hunger = 0
        prey.health = 1
        self.sim.prey.append(prey)
        
        # Run one update cycle which should decrease health and mark prey as dead
        self.sim.manage_health_and_hunger()
        self.assertTrue(prey.is_dead)
        
        # Set death timer to expire
        prey.death_timer = 0.03
        
        # Run another cycle which should remove the prey
        self.sim.manage_health_and_hunger()
        self.assertEqual(len(self.sim.prey), 0)

    def test_food_consumption(self):
        # Spawn prey and food
        prey = Prey(100, 100, 0, 0)
        prey.hunger = 0.0  # Set initial hunger to match expected value
        self.sim.prey.append(prey)
        food = Food(100, 100, size=5)  # Exact same position
        self.sim.food_items = [food]

        # Run consumption check
        self.sim.update()
        self.assertEqual(len(self.sim.food_items), 0)
        # Hunger should go up to 100 -> 95 + food value then decreased by 0.2 per update
        self.assertAlmostEqual(prey.hunger, 59.8, places=2)  # Expecting 100 - 0.2

    def test_manage_health_and_hunger_reproduction_and_removal(self):
        # Prey reproduction
        p = Prey(0,0,0,0)
        p.hunger = 96
        p.reproduction_chance = 1.0
        self.sim.prey = [p]
        self.sim.predators = []
        before = len(self.sim.prey)
        random.seed(1)
        self.sim.manage_health_and_hunger()
        self.assertEqual(len(self.sim.prey), before+1)
        # Removal after death timer
        dead = Prey(0,0,0,0)
        dead.is_dead = True
        dead.death_timer = 0
        self.sim.prey = [dead]
        self.sim.manage_health_and_hunger()
        self.assertEqual(len(self.sim.prey), 0)
    
    def test_limit_force_scaling(self):
        big = (3,4)  # magnitude 5
        out = self.sim.limit_force(big, 3)
        self.assertAlmostEqual(math.hypot(*out), 3)
        small = (1,1)
        self.assertEqual(self.sim.limit_force(small, 5), small)

    def test_spawn_predator_limit(self):
        self.sim.predators = [Predator(0,0,0,0) for _ in range(self.sim.max_predators)]
        success = self.sim.spawn_boid('predator', 10, 10)
        self.assertFalse(success)
        self.assertEqual(len(self.sim.predators), self.sim.max_predators)

    def test_spawn_boid_exception(self):
        # Make obstacle.contains raise
        bad_ob = Obstacle(0,0,1)
        def bad_contains(x, y):
            raise RuntimeError("oops")
        bad_ob.contains = bad_contains
        self.sim.obstacles = [bad_ob]
        with self.assertRaises(Exception) as cm:
            self.sim.spawn_boid('prey', 5, 5)
        self.assertIn('Failed to spawn boid', str(cm.exception))
    
    def test_generate_obstacles_count_and_bounds(self):
        count = 5
        self.sim.screen_width = 200
        self.sim.screen_height = 100
        self.sim.generate_obstacles(count=count)
        self.assertEqual(len(self.sim.obstacles), count)
        for ob in self.sim.obstacles:
            self.assertTrue(50 <= ob.x <= 150)
            self.assertTrue(50 <= ob.y <= 50)

    def test_generate_obstacles_exception(self):
        with patch('random.randint', side_effect=ValueError('rand fail')):
            with self.assertRaises(Exception) as cm:
                self.sim.generate_obstacles(count=1)
            self.assertIn('Failed to generate obstacles', str(cm.exception))
        
    def test_reset_exception(self):
        # Patch generate_obstacles to throw
        self.sim.generate_obstacles = lambda: (_ for _ in ()).throw(Exception('go boom'))
        with self.assertRaises(Exception) as cm:
            self.sim.reset()
        self.assertIn('Failed to reset simulation', str(cm.exception))

    def test_save_load_obstacles_and_food(self):
        # custom obstacles/food
        self.sim.obstacles = [Obstacle(1,2,3)]
        self.sim.food_items = [Food(4,5,6)]
        state = self.sim.save_state()
        # clear
        self.sim.obstacles = []
        self.sim.food_items = []
        # load
        self.sim.load_state(state)
        self.assertEqual(len(self.sim.obstacles), 1)
        self.assertEqual(self.sim.obstacles[0].x, 1)
        self.assertEqual(len(self.sim.food_items), 1)
        self.assertEqual(self.sim.food_items[0].x, 4)
    
    def test_load_state_missing_field(self):
        # preset lists
        old_obs = list(self.sim.obstacles)
        bad_state = {'prey': [], 'predators': [], 'obstacles': [{'x':1}], 'food': []}
        with self.assertRaises(Exception) as cm:
            self.sim.load_state(bad_state)
        self.assertIn('Invalid state format', str(cm.exception))
        # rolled back
        self.assertEqual(self.sim.obstacles, old_obs)

    def test_update_paused(self):
        self.sim.is_paused = True
        # patch submethod to raise
        self.sim.update_prey = lambda: (_ for _ in ()).throw(Exception('should not run'))
        # should not raise
        self.sim.update()

    def test_update_happy_path(self):
        self.sim.is_paused = False
        calls = []
        self.sim.update_prey = lambda: calls.append('prey')
        self.sim.update_predators = lambda: calls.append('pred')
        self.sim.update_boid_positions = lambda: calls.append('pos')
        self.sim.handle_hunting = lambda: calls.append('hunt')
        self.sim.manage_health_and_hunger = lambda: calls.append('mh')
        self.sim.update()
        self.assertEqual(calls, ['prey','pred','pos','hunt','mh'])

    def test_update_exception_wrapped(self):
        self.sim.is_paused = False
        self.sim.update_prey = lambda: (_ for _ in ()).throw(RuntimeError('bad'))
        with self.assertRaises(Exception) as cm:
            self.sim.update()
        self.assertIn('Failed to update simulation', str(cm.exception))

    def test_update_prey_minimum_speed(self):
        p = Prey(0,0,0,0)
        p.vel_x = p.vel_y = 0
        self.sim.prey = [p]
        self.sim.predators = []
        self.sim.food_items = []
        self.sim.update_prey()
        self.assertFalse(p.vel_x == 0 and p.vel_y == 0)
    
    def test_update_boid_positions_calls(self):
        class Dummy:
            def __init__(self): self.log = []
            def update(self): self.log.append('u')
            def check_boundaries(self, w,h,t): self.log.append('b')
            def avoid_obstacles(self, obs): self.log.append('a')
            def resolve_collision(self, obs): self.log.append('r')
        d1 = Dummy(); d2 = Dummy()
        self.sim.prey = [d1]; self.sim.predators = [d2]
        self.sim.obstacles = []
        self.sim.update_boid_positions()
        for d in [d1,d2]:
            self.assertEqual(d.log, ['u','b','a','r'])
        
    def test_handle_hunting_no_action(self):
        prey = Prey(0,0,0,0)
        pred = Predator(100,100,1,1)
        pred.attack_range = 5
        self.sim.prey = [prey]; self.sim.predators = [pred]
        self.sim.handle_hunting()
        self.assertFalse(prey.is_dead)
        self.assertEqual(pred.kda, 0)
    
    def test_handle_hunting_success(self):
        prey = Prey(1,0,0,0)
        pred = Predator(0,0,1,0)
        pred.attack_range = 5
        pred.aggression = 100
        self.sim.prey = [prey]; self.sim.predators = [pred]
        self.sim.handle_hunting()
        self.assertTrue(prey.is_dead)
        self.assertAlmostEqual(prey.death_timer, 0.5)
        self.assertEqual(pred.kda, 1)
        self.assertEqual(pred.hunger, min(100, pred.hunger + 35))
    
    def test_manage_health_and_hunger_decay_and_death(self):
        prey = Prey(0,0,0,0)
        prey.hunger = 0
        prey.health = 1
        self.sim.prey = [prey]
        self.sim.predators = []
        self.sim.manage_health_and_hunger()
        self.assertTrue(prey.is_dead)

    def tearDown(self):
        return super().tearDown()
    

if __name__ == '__main__':
    unittest.main()