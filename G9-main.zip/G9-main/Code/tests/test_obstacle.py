import math
import sys
import os
import unittest

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from obstacle import Obstacle
from boid import Boid

class TestObstacles(unittest.TestCase):
    def setUp(self):
        self.obstacle = Obstacle(100, 100, 20)
        self.boid = Boid(110, 110, vel_x=1, vel_y=1)

    def test_obstacle_creation(self):
        self.assertEqual(self.obstacle.x, 100)
        self.assertEqual(self.obstacle.y, 100)
        self.assertEqual(self.obstacle.radius, 20)
        
        # Test invalid radius
        with self.assertRaises(Exception):
            Obstacle(0, 0, -5)

    def test_collision_detection(self):
        # Exact edge
        self.assertTrue(self.obstacle.contains(100 + 20, 100))
        # Just inside
        self.assertTrue(self.obstacle.contains(100 + 19.9, 100))
        # Just outside
        self.assertFalse(self.obstacle.contains(100 + 20.1, 100))
        # Diagonal calculation
        self.assertTrue(self.obstacle.contains(114, 114))  # sqrt(14²+14²) ≈19.8 <20

    def test_boid_avoidance_mechanics(self):
        # Test avoidance direction
        original_velocity = (self.boid.vel_x, self.boid.vel_y)
        steering = self.boid.avoid_obstacles([self.obstacle])
        
        # Calculate expected escape vector
        dx = self.obstacle.x - self.boid.x
        dy = self.obstacle.y - self.boid.y
        expected_angle = math.atan2(-dy, -dx)
        
        # Get actual steering angle
        steering_magnitude = math.hypot(*steering)
        if steering_magnitude > 0:
            actual_angle = math.atan2(steering[1], steering[0])
            self.assertAlmostEqual(actual_angle, expected_angle, delta=0.1)

    def test_collision_resolution(self):
        # Place boid directly inside obstacle
        self.boid.x = 100
        self.boid.y = 100
        self.assertTrue(self.obstacle.contains(self.boid.x, self.boid.y))
        
        self.boid.resolve_collision([self.obstacle])
        self.assertFalse(self.obstacle.contains(self.boid.x, self.boid.y))
        
        # Verify minimum distance
        distance = math.hypot(self.boid.x - 100, self.boid.y - 100)
        self.assertGreaterEqual(distance, 20 + 2)  # 22

    def test_multiple_obstacles(self):
        obstacles = [
            Obstacle(90, 90, 15),
            Obstacle(110, 110, 15),
            Obstacle(100, 150, 20)
        ]
        
        # Store original velocity components
        original_vx = self.boid.vel_x
        original_vy = self.boid.vel_y
        
        steering = self.boid.avoid_obstacles(obstacles)
        self.assertNotEqual(steering, (0, 0))
        
        # Verify cumulative effect
        self.assertNotEqual(self.boid.vel_x, original_vx)
        self.assertNotEqual(self.boid.vel_y, original_vy)
        self.assertTrue(math.hypot(self.boid.vel_x, self.boid.vel_y) <= self.boid.max_speed)

    def test_avoidance_priority(self):
        # Close obstacle vs distant obstacle
        close_obstacle = Obstacle(105, 105, 10)
        far_obstacle = Obstacle(200, 200, 30)
        
        steering = self.boid.avoid_obstacles([close_obstacle, far_obstacle])
        
        # Should prioritize close obstacle
        close_vector = (close_obstacle.x - self.boid.x, close_obstacle.y - self.boid.y)
        expected_direction = math.atan2(-close_vector[1], -close_vector[0])
        actual_direction = math.atan2(steering[1], steering[0])
        self.assertAlmostEqual(actual_direction, expected_direction, delta=0.1)

if __name__ == '__main__':
    unittest.main()