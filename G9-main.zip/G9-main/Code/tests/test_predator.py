import unittest
from unittest.mock import MagicMock
import math

import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from predator import Predator

class TestPredator(unittest.TestCase):
    def setUp(self):
        self.predator = Predator(100, 200, 1.5, -2.0)
        self.prey_mock = MagicMock()
        self.prey_mock.x = 110
        self.prey_mock.y = 210

    def test_initialization(self):
        self.assertEqual(self.predator.hunger, 94.0)
        self.assertEqual(self.predator.health, 100.0)
        self.assertEqual(self.predator.attack_range, 25.0)
        self.assertEqual(self.predator.base_max_speed, 3.0)
        self.assertEqual(self.predator.chase_max_speed, 5.0)

    def test_update_hunger_effects(self):
        # Test at max hunger
        self.predator.hunger = 100.0
        self.predator.update_hunger_effects()
        self.assertAlmostEqual(self.predator.max_speed, 3.0, delta=0.01)

        # Test at min hunger
        self.predator.hunger = 0.0
        self.predator.update_hunger_effects()
        self.assertAlmostEqual(self.predator.max_speed, 5.0, delta=0.01)

    def test_chase_prey_no_target(self):
        steering = self.predator.chase_prey([])
        self.assertEqual(steering, (0, 0))
        self.assertFalse(self.predator.chase_mode)

    def test_chase_prey_with_target(self):
        steering = self.predator.chase_prey([self.prey_mock])
        self.assertTrue(self.predator.chase_mode)
        self.assertIs(self.predator.target_prey, self.prey_mock)
        self.assertNotEqual(steering, (0, 0))

if __name__ == '__main__':
    unittest.main()