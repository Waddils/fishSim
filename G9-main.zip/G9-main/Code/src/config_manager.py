import json
import logging
import os
from datetime import datetime
import tkinter.filedialog as filedialog
class Config_Manager:
    def __init__(self):
        """
        Init config manager with logs
        """
        # Related doc - https://docs.python.org/3/library/logging.html
        current_dir = os.path.dirname(os.path.abspath(__file__))
        parent_dir = os.path.dirname(current_dir)
        logs_dir = os.path.join(parent_dir, "data", "logs")

        os.makedirs(logs_dir, exist_ok=True)
        
        log_date = datetime.now().strftime("%Y-%m-%d")
        log_file = os.path.join(logs_dir, f"aquarium_sim_{log_date}.log")

        logging.basicConfig(filename=log_file,level=logging.INFO,
                            format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
        
        self.logger = logging.getLogger()

    def log_error(self, err_msg):
        self.logger.error(err_msg)

    def log_info(self, info_msg):
        self.logger.info(info_msg)

    def save_config(self, data):
        """
        Save simulation state to JSON file
        """
        try:
            file_path = filedialog.asksaveasfilename(
                defaultextension=".json",
                filetypes=[("JSON files", "*.json")]
            )
            if file_path:
                with open(file_path, 'w') as f:
                    json.dump(data, f)
                self.log_info(f"Configuration saved successfully to {file_path}")
                return True
            return False
        except Exception as e:
            err_msg = f"Failed to save configuration: {str(e)}"
            self.log_error(err_msg)
            return False

    def load_config(self):
        """
        Load simulation state from JSON file
        """
        try:
            file_path = filedialog.askopenfilename(
                filetypes=[("JSON files", "*.json")]
            )
            if file_path:
                with open(file_path, 'r') as f:
                    data = json.load(f)
                self.log_info(f"Configuration loaded successfully from {file_path}")
                return data, None
            return None, None
        except json.JSONDecodeError:
            error_msg = f"Failed to load configuration: Invalid JSON format in {file_path}"
            self.log_error(error_msg)
            return None, error_msg
        except FileNotFoundError:
            error_msg = f"Failed to load configuration: File not found at {file_path}"
            self.log_error(error_msg)
            return None, error_msg
        except Exception as e:
            error_msg = f"Failed to load configuration: {str(e)}"
            self.log_error(error_msg)
            return None, error_msg