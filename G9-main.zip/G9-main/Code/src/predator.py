"""
Predator inherits from boid class for movement
"""

from boid import Boid
import math

class Predator(Boid):
    def __init__(self, x, y, vel_x, vel_y):
        super().__init__(x, y, vel_x, vel_y)
        self.hunger = 94.0 # Start with less than reproduction rate (>95)
        self.health = 100.0
        self.aggression = 50.0
        self.attack_range = 25.0  # pixels
        self.reproduction_chance = 0.1 # 10% chance
        self.children_count = 0 # Number of children spawned
        self.kda = 0 # k-count
        
        # Base movement parameters
        self.base_max_speed = 3.0  # Slower default speed
        self.chase_max_speed = 5.0  # Fast when chasing
        self.max_speed = self.base_max_speed
        
        self.alignment_weight = 1.5
        self.cohesion_weight = 0.8
        self.separation_weight = 1.5
        
        # Chase parameters
        self.prey_detection_radius = 150  # Pixels
        self.chase_weight = 2.5
        self.chase_mode = False
        self.target_prey = None
    
    def update_hunger_effects(self):
        """
        Adjust speed based on hunger levels
        """
        # As hunger decreases (0-100), speed increases up to the chase max speed
        hunger_factor = self.hunger / 100.0
        speed_range = self.chase_max_speed - self.base_max_speed
        
        # More aggressive speed increase as hunger gets lower
        hunger_effect = 1.0 - (hunger_factor ** 2)  # Non-linear effect
        self.max_speed = self.base_max_speed + (speed_range * hunger_effect)
    
    def chase_prey(self, prey_list):
        """
        Calculate steering force to chase nearby prey
        """
        # Reset chase mode
        self.chase_mode = False
        self.target_prey = None
        
        if not prey_list:
            return (0, 0)
        
        # Find closest prey within detection radius
        closest_prey = None
        closest_distance = float('inf')
        
        for prey in prey_list:
            distance = self.distance_to(prey)
            if distance < self.prey_detection_radius and distance < closest_distance:
                closest_prey = prey
                closest_distance = distance
        
        # If no prey in range, return zero steering
        if not closest_prey:
            return (0, 0)
        
        # We found a target
        self.chase_mode = True
        self.target_prey = closest_prey
        
        # Vector to prey
        to_prey_x = closest_prey.x - self.x
        to_prey_y = closest_prey.y - self.y
        
        # Normalize and scale to max speed
        distance = math.sqrt(to_prey_x**2 + to_prey_y**2)
        if distance > 0:
            to_prey_x = (to_prey_x / distance) * self.max_speed
            to_prey_y = (to_prey_y / distance) * self.max_speed
        
        # Calculate steering force
        steering_x = to_prey_x - self.vel_x
        steering_y = to_prey_y - self.vel_y
        
        # Apply chase weight - stronger steering when closer to prey
        proximity_factor = 1.0 - (distance / self.prey_detection_radius)
        steering_weight = self.chase_weight * (1 + proximity_factor)
        
        steering_x *= steering_weight
        steering_y *= steering_weight
        
        # Allow stronger force for chasing
        chase_force = self.max_force * (1.5 + proximity_factor)
        return self.limit_force((steering_x, steering_y), chase_force)