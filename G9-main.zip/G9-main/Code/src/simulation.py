"""
Simulation class for managing the state of the boids and environment
"""
import random
import math

from prey import Prey
from predator import Predator
from food import Food
from obstacle import Obstacle
from config_manager import Config_Manager
class Simulation:
    
    def __init__(self):
        self.config_manager = Config_Manager()
        self.food_items = []
        self.prey = [] 
        self.predators = []
        self.max_prey = 60  # Maximum prey allowed
        self.max_predators = 60  # Maximum predators allowed

        self.boundary_top = 26

        self.is_paused = False
        self.screen_width = 800  # Should match test dimensions
        self.screen_height = 600
        self.generate_obstacles()
        self.spawn_food()


    def spawn_boid(self, boid_type, x=None, y=None, max_attempts=100):
        """
        Spawns a boid at a randomly valid position on the screen.
        """
        try:
            # Check population limits before spawning
            if boid_type == "prey" and len(self.prey) >= self.max_prey:
                self.config_manager.log_info(f"Prey spawn blocked - reached max {self.max_prey}")
                return False
            if boid_type == "predator" and len(self.predators) >= self.max_predators:
                self.config_manager.log_info(f"Predator spawn blocked - reached max {self.max_predators}")
                return False

            valid_position = False
            attempt_num = 0
        
            if x is not None and y is not None:
                valid_position = True
                for obstacle in self.obstacles:
                    if obstacle.contains(x, y):
                        valid_position = False
                        break
        
                # Spawn boid
                if valid_position:
                    vel_x = random.uniform(-3, 3)
                    vel_y = random.uniform(-3, 3)
                    if boid_type == "prey":
                        new_boid = Prey(x, y, vel_x, vel_y)
                        self.prey.append(new_boid)
                    else:
                        new_boid = Predator(x, y, vel_x, vel_y)
                        self.predators.append(new_boid)
                    return True
                else:
                    return False
    
            # Try to find a random valid position
            while attempt_num < max_attempts:
                x = random.randint(0, self.screen_width)
                y = random.randint(0, self.screen_height)

                valid_position = True
                for obstacle in self.obstacles:
                    if obstacle.contains(x, y):
                        valid_position = False
                        break
        
                if valid_position:
                    vel_x = random.uniform(-3, 3)
                    vel_y = random.uniform(-3, 3)
                    if boid_type == "prey":
                        new_boid = Prey(x, y, vel_x, vel_y)
                        self.prey.append(new_boid)
                    else:
                        new_boid = Predator(x, y, vel_x, vel_y)
                        self.predators.append(new_boid)
                    return True

                attempt_num += 1
    
            # Failed to find valid position after max attempts
            return False
        except Exception as e:
            # Any exception is considered a failure
            raise Exception(f"Failed to spawn boid: {str(e)}")

    def generate_obstacles(self, count=10):
        """
        Gen obstacles at random positions on the screen
        """
        try:
            self.obstacles = []
            for _ in range(count):
                x = random.randint(50, self.screen_width-50)
                y = random.randint(50, self.screen_height-50)
                self.obstacles.append(Obstacle(x, y, 20))
        except Exception as e:
            raise Exception(f"Failed to generate obstacles: {str(e)}")

    def spawn_food(self):
        """
        Dynamically spawns food based on the fish population.
        Adds new food without removing existing food items.
        """
        try:
            fish_count = len(self.prey)
            
            if (fish_count == 0):
                return

            if (fish_count < 30):
                food_per_fish_ratio = 0.3
            else:
                food_per_fish_ratio = 0.15

            boundary_top = getattr(self, 'boundary_top')

            food_count = math.ceil(max(1, (fish_count * food_per_fish_ratio)))
            print("Food Count: ", food_count)

            # Spawn food items
            for _ in range(food_count):
                food = Food.spawn_random(
                    self.screen_width - 50,
                    self.screen_height - 50,
                    self.obstacles,
                    boundary_top=boundary_top
                )
                self.food_items.append(food)
                self.config_manager.log_info(f"Spawned food at ({food.x}, {food.y})")

        except ValueError as e:
            self.config_manager.log_error(f"Food spawn failed: {str(e)}")
            raise Exception(f"Failed to spawn food: {str(e)}")

    def reset(self):
        """
        Clears all objects and resets simulation with new objects and food start
        """
        try:
            self.prey = []
            self.predators = []
            self.food_items = []
            self.generate_obstacles()
            self.spawn_food()
        except Exception as e:
            raise Exception(f"Failed to reset simulation: {str(e)}")

    def pause(self):
        """
        Pauses the simulation.
        """
        try:
            self.is_paused = True
        except Exception as e:
            raise Exception(f"Failed to pause simulation: {str(e)}")
    
    def resume(self):
        """
        Resumes the simulation.
        """
        try:
            self.is_paused = False
        except Exception as e:
            raise Exception(f"Failed to resume simulation: {str(e)}")

    def save_state(self):
        """
        Saves simulation data to a dictionary
        """
        try:
            return {
                "prey": [
                    {
                        "x": prey.x,
                        "y": prey.y,
                        "vel_x": prey.vel_x,
                        "vel_y": prey.vel_y,
                        "hunger": prey.hunger,
                        "health": prey.health,
                        "reproduction_chance": prey.reproduction_chance,
                        "children_count": prey.children_count
                    } for prey in self.prey
                ],
                "predators": [
                    {
                        "x": predator.x,
                        "y": predator.y,
                        "vel_x": predator.vel_x,
                        "vel_y": predator.vel_y,
                        "hunger": predator.hunger,
                        "health": predator.health,
                        "aggression": predator.aggression,
                        "attack_range": predator.attack_range,
                        "reproduction_chance": predator.reproduction_chance,
                        "children_count": predator.children_count,
                        "kda": predator.kda
                    } for predator in self.predators
                ],
                "obstacles": [
                    {
                        "x": obstacle.x,
                        "y": obstacle.y,
                        "radius": obstacle.radius
                    } for obstacle in self.obstacles
                ],
                "food": [
                    {
                        "x": food.x,
                        "y": food.y,
                        "size": food.size,
                        "decay_time": food.decay_time
                    } for food in self.food_items
                ]
            }
        except Exception as e:
            raise Exception(f"Failed to save simulation state: {str(e)}")

    def load_state(self, state):
        """
        Loads simulation state from a dictionary
        """
        try:
            # Store current state for rollback in case of error
            old_prey = self.prey.copy()
            old_predators = self.predators.copy()
            old_obstacles = self.obstacles.copy()
            old_food_items = self.food_items.copy()
        
            # Reset and load new state
            self.prey = []
            self.predators = []
            self.food_items = []
        
            # Load prey
            for prey_data in state.get("prey", []):
                new_prey = Prey(
                    x=prey_data["x"],
                    y=prey_data["y"],
                    vel_x=prey_data["vel_x"],
                    vel_y=prey_data["vel_y"]
                )
                new_prey.hunger = prey_data["hunger"]
                new_prey.health = prey_data["health"]
                new_prey.reproduction_chance = prey_data["reproduction_chance"]
                new_prey.children_count = prey_data.get("children_count", 0)
                self.prey.append(new_prey)
            
            # Load predators
            for predator_data in state.get("predators", []):
                new_predator = Predator(
                    x=predator_data["x"],
                    y=predator_data["y"],
                    vel_x=predator_data["vel_x"],
                    vel_y=predator_data["vel_y"]
                )
                new_predator.hunger = predator_data["hunger"]
                new_predator.health = predator_data["health"]
                new_predator.attack_range = predator_data["attack_range"]
                new_predator.aggression = predator_data["aggression"]
                new_predator.reproduction_chance = predator_data["reproduction_chance"]
                new_predator.children_count = predator_data.get("children_count", 0)
                new_predator.kda = predator_data.get("kda", 0)
                self.predators.append(new_predator)
            
            # Load obstacles
            if "obstacles" in state:
                self.obstacles = []
                for obstacle_data in state["obstacles"]:
                    self.obstacles.append(Obstacle(
                        x=obstacle_data["x"],
                        y=obstacle_data["y"],
                        radius=obstacle_data["radius"]
                    ))
            
            # Load food items
            if "food" in state:
                self.food_items = []
                for food_data in state["food"]:
                    self.food_items.append(Food(
                        x=food_data["x"],
                        y=food_data["y"],
                        size=food_data["size"],
                        decay_time=food_data["decay_time"]
                    ))
                
            self.config_manager.log_info(
                f"Loaded state: {len(state.get('prey', []))} prey, "
                f"{len(state.get('predators', []))} predators, "
                f"{len(state.get('obstacles', []))} obstacles"
                f"{len(state.get('food', []))} food items"
            )

            return True
            
        except KeyError as e:
            # Rollback on error
            self.prey = old_prey
            self.predators = old_predators
            self.obstacles = old_obstacles
            self.food_items = old_food_items
            raise Exception(f"Invalid state format: Missing required field {str(e)}")
        
        except Exception as e:
            # Rollback on error
            self.prey = old_prey
            self.predators = old_predators
            self.obstacles = old_obstacles
            self.food_items = old_food_items
            raise Exception(f"Failed to load simulation state: {str(e)}")
    
    def update(self):
        """
        Updates the simulation state with proper flocking, hunting, and health management.
        """
        if self.is_paused:
            return
            
        try:         
            # Update all prey behaviors and movements
            self.update_prey()

            # Update all predator behaviors and movements
            self.update_predators()

            # Handle boundary checks and obstacle avoidance for all boids
            self.update_boid_positions()

            # Handle predator-prey interactions and hunger
            self.handle_hunting()
            self.manage_health_and_hunger()

        except Exception as e:
            raise Exception(f"Failed to update simulation: {str(e)}")

    def update_prey(self):
        """
        Update prey flocking, predator avoidance, and obstacle hiding
        """
        for prey in self.prey:
            # Ensure minimum velocity to prevent complete stopping
            current_speed = math.hypot(prey.vel_x, prey.vel_y)
            if current_speed < 0.5:  # Minimum speed threshold
                # Add small random velocity to break out of stalemate
                prey.vel_x += random.uniform(-0.5, 0.5)
                prey.vel_y += random.uniform(-0.5, 0.5)
                prey.limit_speed()
                
            # Existing neighbor detection
            neighbors = [p for p in self.prey 
                        if p != prey and 
                        prey.distance_to(p) < prey.neighbor_radius]

            # Calculate flocking forces
            align = prey.calculate_alignment(neighbors)
            cohere = prey.calculate_cohesion(neighbors)
            separate = prey.calculate_separation(neighbors)
            
            # Food-seeking behavior
            if prey.hunger <= 70.0:  # Include food-seeking behavior only if hunger is low
                seek_food = prey.seek_closest_food(self.food_items)
            else:
                seek_food = (0, 0)  # No contribution to movement
            
            # Detect nearby predators
            nearby_predators = [p for p in self.predators 
                            if prey.distance_to(p) < prey.predator_detection_radius]
            
            # Predator avoidance - only if predators are actually nearby
            if nearby_predators:
                seek_food = (0, 0)  # Ignore food-seeking when predators are too close
                avoid_predators = prey.avoid_predators(self.predators)
                # If avoiding predators, increase the weight
                avoidance_factor = 2.5  # Higher priority when actually needed
            else:
                avoid_predators = (0, 0)
                avoidance_factor = prey.predator_avoidance_weight
            
            # Obstacle hiding - only if predators are nearby
            if nearby_predators:
                hide = prey.hide_behind_obstacles(self.obstacles, self.predators)
            else:
                hide = (0, 0)

            # Add stronger wandering behavior
            wander_strength = 0.8  # Increased from default value
            wander = (
                random.uniform(-1.0, 1.0) * wander_strength * prey.independence_factor,
                random.uniform(-1.0, 1.0) * wander_strength * prey.independence_factor
            )

            # Combine all forces with momentum preservation
            # Keep a portion of current velocity for momentum
            momentum_factor = 0.6
            momentum = (prey.vel_x * momentum_factor, prey.vel_y * momentum_factor)
            
            # Combine forces with careful weighting
            total_force_x = (
                align[0] * prey.alignment_weight +
                cohere[0] * prey.cohesion_weight +
                separate[0] * prey.separation_weight +
                seek_food[0] +
                avoid_predators[0] * avoidance_factor +
                hide[0] * prey.hiding_weight +
                wander[0] +
                momentum[0]
            )
            
            total_force_y = (
                align[1] * prey.alignment_weight +
                cohere[1] * prey.cohesion_weight +
                separate[1] * prey.separation_weight +
                seek_food[1] + 
                avoid_predators[1] * avoidance_factor +
                hide[1] * prey.hiding_weight +
                wander[1] +
                momentum[1]
            )

            # Use direct velocity update instead of gradual force application
            # when forces are very small
            force_magnitude = math.hypot(total_force_x, total_force_y)
            if force_magnitude < 0.1:  # If forces are tiny, add direct impulse
                prey.vel_x += random.uniform(-0.8, 0.8)
                prey.vel_y += random.uniform(-0.8, 0.8)
            else:
                # Apply forces with higher weight for more movement
                prey.apply_force(total_force_x, total_force_y, 1.5)  # Increased weight
            
            prey.limit_speed()
            
            # Check for vicinty-based collision with food objects
            for prey in self.prey:
                for food in self.food_items:
                    if prey.check_food_collision(food):
                        prey.consume_food(food, self.food_items) 

    def update_predators(self):
        """
        Update predator flocking and prey chasing
        """
        for predator in self.predators:
            # Existing neighbor detection
            neighbors = [p for p in self.predators 
                        if p != predator and 
                        predator.distance_to(p) < predator.neighbor_radius]

            # Calculate flocking forces
            align = predator.calculate_alignment(neighbors)
            cohere = predator.calculate_cohesion(neighbors)
            separate = predator.calculate_separation(neighbors)
            
            # Prey chasing
            chase = predator.chase_prey(self.prey)

            # NEW: Add persistent forward momentum
            momentum = (
                predator.vel_x * 0.3,  # Maintain 30% of current velocity
                predator.vel_y * 0.3
            )

            # Combine forces
            total_force_x = (
                align[0] * predator.alignment_weight +
                cohere[0] * predator.cohesion_weight +
                separate[0] * predator.separation_weight +
                chase[0] * predator.chase_weight +
                momentum[0]  # Add momentum
            )
            
            total_force_y = (
                align[1] * predator.alignment_weight +
                cohere[1] * predator.cohesion_weight +
                separate[1] * predator.separation_weight +
                chase[1] * predator.chase_weight +
                momentum[1]  # Add momentum
            )

            # Apply forces
            predator.apply_force(total_force_x, total_force_y, 1.0)
            predator.limit_speed()
            predator.update_hunger_effects()

    def update_boid_positions(self):
        """
        Update positions and handle environment interactions
        """
        for boid in self.prey + self.predators:
            boid.update()
            boid.check_boundaries(self.screen_width, self.screen_height, self.boundary_top)
            boid.avoid_obstacles(self.obstacles)
            boid.resolve_collision(self.obstacles)

    def handle_hunting(self):
        """
        Handle predator-prey interactions
        """
        dying_prey = []
        for predator in self.predators:
            if predator.is_dead:
                continue
                
            for prey in self.prey:
                # Skip prey already being eaten or dead
                if prey.is_being_eaten or prey.is_dead:
                    continue
                    
                distance = predator.distance_to(prey)
                if distance < predator.attack_range:
                    dx = prey.x - predator.x
                    dy = prey.y - predator.y
                    prey_angle = math.atan2(dy, dx)
                    predator_angle = math.atan2(predator.vel_y, predator.vel_x)
                    angle_diff = abs(prey_angle - predator_angle)
                    
                    if angle_diff < math.pi/2:  # 90 degree frontal cone
                        # Mark prey for shrinking instead of immediate removal
                        prey.is_being_eaten = True
                        dying_prey.append(prey)
                        predator.kda += 1
                        predator.hunger = min(100, predator.hunger + 35)

        # Update shrinking prey
        for prey in self.prey:
            if prey.is_being_eaten:
                prey.is_dead = True
                prey.is_being_eaten = False
                prey.death_timer = 0.5

    def manage_health_and_hunger(self):
        """
        Update hunger/health values and remove dead boids
        """
        dead_prey = []
        dead_predators = []
        
        # Update prey
        for prey in self.prey:
            if not prey.is_dead:
                prey.hunger = max(0, prey.hunger - 0.2)
                
                # Check for reproduction (hunger >= 95)
                if prey.hunger >= 95:
                    if random.random() < prey.reproduction_chance and len(self.prey) < self.max_prey:
                        # Spawn near the parent
                        new_x = prey.x + random.uniform(-20, 20)
                        new_y = prey.y + random.uniform(-20, 20)
                        success = self.spawn_boid("prey", new_x, new_y)
                        if success:
                            prey.hunger = max(0, prey.hunger - 50)  # Reduce hunger
                            prey.children_count += 1  # Increment children count
                            self.config_manager.log_info(f"New Prey spawned at ({new_x}, {new_y})")
                
                if prey.hunger <= 0:
                    prey.health -= 1
                    if prey.health <= 0:
                        prey.is_dead = True
        
        # Update predators
        for predator in self.predators:
            if not predator.is_dead:
                predator.hunger = max(0, predator.hunger - 0.3)
                
                # Check for reproduction (hunger >= 95)
                if predator.hunger >= 95:
                    if random.random() < predator.reproduction_chance and len(self.predators) < self.max_predators:
                        # Spawn near the parent
                        new_x = predator.x + random.uniform(-20, 20)
                        new_y = predator.y + random.uniform(-20, 20)
                        success = self.spawn_boid("predator", new_x, new_y)
                        if success:
                            predator.hunger = max(0, predator.hunger - 50)  # Reduce hunger
                            predator.children_count += 1  # Increment children count
                            self.config_manager.log_info(f"New Predator spawned at ({new_x}, {new_y})")
                
                if predator.hunger <= 0:
                    predator.health -= 1
                    if predator.health <= 0:
                        predator.is_dead = True
        
        # Remove dead boids
        current_time = 0.033  # 33ms(?) per frame (~30 FPS)
        for boid in self.prey + self.predators:
            if boid.is_dead:
                boid.death_timer -= current_time
                if boid.death_timer <= 0:
                    if isinstance(boid, Prey):
                        dead_prey.append(boid)
                    else:
                        dead_predators.append(boid)
        
        # Remove fully expired boids
        for prey in dead_prey:
            self.prey.remove(prey)
        for predator in dead_predators:
            self.predators.remove(predator)

    def limit_force(self, force, max_force):
            """
            Limit the magnitude of a steering force
            """
            fx, fy = force
            magnitude = math.hypot(fx, fy)
            if magnitude > max_force:
                scale = max_force / magnitude
                return (fx * scale, fy * scale)
            return force