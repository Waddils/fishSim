"""
Main file to run for the program
"""

from pygame_gui import PygameGUI
from simulation import Simulation

if __name__ == "__main__":
    sim = Simulation()
    game = PygameGUI(sim)
    game.run()