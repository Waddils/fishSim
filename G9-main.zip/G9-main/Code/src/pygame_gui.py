import pygame
import math
import os
import tkinter as tk

from predator import Predator
from prey import Prey
from config_manager import Config_Manager

from pygame.locals import *
from tkinter import Tk

"""
pygame gui class to handle the simulation visuals and user input
"""
class PygameGUI:
    def __init__(self, sim):
        self.sim = sim
        self.config_manager = Config_Manager()

        self.screen_width = 800
        self.screen_height = 650  # Extra space for UI
        
        self.sim_area_top = 28    # Top UI area height
        self.sim_area_height = self.screen_height - self.sim_area_top
        
        self.sim.screen_height = self.sim_area_height  # Simulation area height
        self.sim.boundary_top = self.sim_area_top      # Top boundary offset

        self.running = True
        self.clock = pygame.time.Clock()
        self.font = None
        self.sprites = {}
        self.buttons = []

        self.food_spawn_event = pygame.USEREVENT + 1

        self.spawn_dropdown_active = False
        self.spawn_dropdown_rect = pygame.Rect(0, 0, 180, 80)
        self.spawn_amount = "1"  # Default spawn amount
        self.input_active = False

        # Metric overlay
        self.selected_boid = None
        self.overlay_position = (100, 100)
        self.is_dragging_overlay = False
        self.drag_offset = (0, 0)
        
        # Pygame initialization
        pygame.init()
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Aquarium Simulator")
        self.font = pygame.font.Font(None, 24)
        self.small_font = pygame.font.Font(None, 20)
        pygame.time.set_timer(self.food_spawn_event, 4000)  # 4000ms = 4 seconds timer for food spawn
        
        # Load resources
        self.load_sprites()
        self.create_buttons()

    def load_sprites(self):
        """
        Load all game sprites with caching
        """
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            textures_dir = os.path.join(current_dir, "..", "textures")

            # Load fish sprites
            self.sprites['prey'] = self.load_image(
                os.path.join(textures_dir, "fish_prey(blue).png"))
            self.sprites['predator'] = self.load_image(
                os.path.join(textures_dir, "fish_predator(red).png"))

            # Load UI elements
            self.sprites['background'] = self.load_image(
                os.path.join(textures_dir, "bgt.png"))
            self.sprites['ui_background'] = self.load_image(
                os.path.join(textures_dir, "border_small.png"))
            self.sprites['spawn_button'] = self.load_image(
                os.path.join(textures_dir, "spawn-fish-button.png"))
            self.sprites['pause_button'] = self.load_image(
                os.path.join(textures_dir, "pause-button.png"))
            self.sprites['reset_button'] = self.load_image(
                os.path.join(textures_dir, "reset-button.png"))
            self.sprites['save_button'] = self.load_image(
                os.path.join(textures_dir, "save-button.png"))
            self.sprites['load_button'] = self.load_image(
                os.path.join(textures_dir, "load-button.png"))
            self.sprites['obstacle'] = self.load_image(
                os.path.join(textures_dir, "barnacle.png"))
            
            # Load food
            food_path = os.path.join(textures_dir, "shrimp.png")
            food_image = pygame.image.load(food_path).convert_alpha()
            food_image = pygame.transform.scale(food_image, (20, 20))  # Resize to 20x20
            self.sprites['food'] = food_image

        except Exception as e:
            self.config_manager.log_error(f"Sprite load failed: {str(e)}")
            pygame.quit()
            exit()

    def load_image(self, path):
        """
        Optimized image loading with conversion
        """
        try:
            image = pygame.image.load(path).convert_alpha()
            return image
        except Exception as e:
            print(f"Error loading {path}: {e}")
            return pygame.Surface((32, 32), pygame.SRCALPHA)

    def create_buttons(self):
        """
        Create UI buttons with positions
        """
        button_spacing = 10
        start_x = 250
        start_y = 10
        
        buttons = [
            ('spawn', self.sprites['spawn_button'], (start_x, start_y)),
            ('pause', self.sprites['pause_button'], (start_x + 92, start_y)),
            ('reset', self.sprites['reset_button'], (start_x + 152, start_y)),
            ('save', self.sprites['save_button'], (start_x + 213, start_y)),
            ('load', self.sprites['load_button'], (start_x + 268, start_y))
        ]
        
        for btn_id, surf, pos in buttons:
            rect = surf.get_rect(topleft=pos)
            self.buttons.append((btn_id, surf, rect))

            if btn_id == 'spawn':
                self.spawn_dropdown_rect.topleft = (rect.left, rect.bottom + 5)

    def rotate_sprite(self, image, angle, sprite_type, scale=1.0):
        """
        Optimized sprite rotation with caching
        """
        key = f"{sprite_type}_{id(image)}_{angle:.2f}_{scale:.2f}"
        if key not in self.sprites:
            rot_image = pygame.transform.rotozoom(image, angle, scale)
            self.sprites[key] = rot_image
        return self.sprites[key]

    def draw_boid(self, boid):
        """
        Draw a boid with proper rotation and scale
        """
        sprite_type = 'prey' if isinstance(boid, Prey) else 'predator'
        base_image = self.sprites[sprite_type].copy()

         # Apply death fade effect
        if boid.is_dead:
            fade_factor = boid.death_timer / 1.0
            alpha = int(255 * fade_factor)
            
            # Create temporary surface for manipulation
            temp_surface = pygame.Surface(base_image.get_size(), pygame.SRCALPHA)
            temp_surface.blit(base_image, (0, 0))
            
            # Modify pixels
            px_array = pygame.PixelArray(temp_surface)
            for x in range(temp_surface.get_width()):
                for y in range(temp_surface.get_height()):
                    color = temp_surface.unmap_rgb(px_array[x, y])
                    if color.a > 0:
                        # Blend towards white
                        new_r = int(color.r * fade_factor + 255 * (1 - fade_factor))
                        new_g = int(color.g * fade_factor + 255 * (1 - fade_factor))
                        new_b = int(color.b * fade_factor + 255 * (1 - fade_factor))
                        px_array[x, y] = (new_r, new_g, new_b, alpha)
            del px_array  # Commit changes
            base_image = temp_surface

        scale = getattr(boid, 'eaten_scale', 1.0)
        if isinstance(boid, Prey) and boid.is_being_eaten and scale > 0:
            new_size = (max(1, int(base_image.get_width() * scale)), 
                        max(1, int(base_image.get_height() * scale)))
            scaled_image = pygame.transform.smoothscale(base_image, new_size)
        else:
            scaled_image = base_image
        
        # Rotate and draw
        angle = math.degrees(math.atan2(-boid.vel_y, boid.vel_x)) + 90
        rotated_image = self.rotate_sprite(scaled_image, angle, sprite_type)
        pos = (int(boid.x), int(boid.y) + self.sim_area_top)
        self.screen.blit(rotated_image, rotated_image.get_rect(center=pos))

    def draw_obstacles(self):
        """
        Draw all obstacles
        """
        obstacle_img = self.sprites['obstacle']
        for obstacle in self.sim.obstacles:
            pos = (int(obstacle.x), int(obstacle.y) + self.sim_area_top)
            self.screen.blit(obstacle_img, obstacle_img.get_rect(center=pos))

    def draw_food(self):
        food_sprite = self.sprites['food']
        food_rect = food_sprite.get_rect()
        positions = [(int(f.x), int(f.y) + self.sim_area_top) for f in self.sim.food_items]
        
        # Batch blit all food items
        for pos in positions:
            food_rect.center = pos
            self.screen.blit(food_sprite, food_rect)

    def draw_ui(self):
        """
        Draw UI elements
        """
        # Backgrounds
        self.screen.blit(self.sprites['ui_background'], (0, 0))
        self.screen.blit(self.sprites['background'], (0, 50))
        
        # Buttons
        for btn_id, surf, rect in self.buttons:
            self.screen.blit(surf, rect)
        
        # Counter text
        text = f"Prey: {len(self.sim.prey)}  Predators: {len(self.sim.predators)}"
        text_surf = self.font.render(text, True, (255, 255, 255))
        self.screen.blit(text_surf, (10, 15))

        # Drawing a rectangle to connect sim and UI
        rect_x = 0  # Starting 50px from left
        rect_y = 46  # 46px from top
        rect_width = 800  # 700px wide
        rect_height = 4   # 4px tall
        pygame.draw.rect(self.screen, (0, 0, 0), (rect_x, rect_y, rect_width, rect_height))
        
    def draw_spawn_dropdown(self):
        """
        Draw the spawn dropdown menu
        """
        # Background
        dropdown = pygame.Rect(self.spawn_dropdown_rect)
        pygame.draw.rect(self.screen, (40, 40, 40), dropdown)
        pygame.draw.rect(self.screen, (100, 100, 100), dropdown, 2)
        
        # Title
        title_text = self.small_font.render("Spawn Boids", True, (255, 255, 255))
        self.screen.blit(title_text, (dropdown.x + 10, dropdown.y + 10))
        
        # Amount text
        amount_text = self.small_font.render("Amount:", True, (255, 255, 255))
        self.screen.blit(amount_text, (dropdown.x + 10, dropdown.y + 35))
        
        # Amount input (simple rectangle for now)
        input_rect = pygame.Rect(dropdown.x + 70, dropdown.y + 35, 40, 20)
        pygame.draw.rect(self.screen, (80, 80, 80), input_rect)
        pygame.draw.rect(self.screen, (150, 150, 150), input_rect, 1)
        
        # Input text (if we had a value)
        if hasattr(self, 'spawn_amount'):
            amount_value = self.small_font.render(str(self.spawn_amount), True, (255, 255, 255))
            self.screen.blit(amount_value, (input_rect.x + 5, input_rect.y + 2))
        
        # Buttons
        prey_btn = pygame.Rect(dropdown.x + 10, dropdown.y + 60, 70, 25)
        pred_btn = pygame.Rect(dropdown.x + 100, dropdown.y + 60, 70, 25)
        
        pygame.draw.rect(self.screen, (0, 100, 200), prey_btn)
        pygame.draw.rect(self.screen, (200, 50, 50), pred_btn)
        
        prey_text = self.small_font.render("Prey", True, (255, 255, 255))
        pred_text = self.small_font.render("Predator", True, (255, 255, 255))
        
        self.screen.blit(prey_text, (prey_btn.x + 20, prey_btn.y + 5))
        self.screen.blit(pred_text, (pred_btn.x + 5, pred_btn.y + 5))
        
        # Store button rects for hit detection
        self.prey_btn_rect = prey_btn
        self.pred_btn_rect = pred_btn
        self.input_rect = input_rect

    def handle_input(self):
        """
        Handle all input
        """
        mouse_pos = pygame.mouse.get_pos()
        
        for event in pygame.event.get():
            if event.type == QUIT:
                self.running = False
            
            elif event.type == self.food_spawn_event:
                if not self.sim.is_paused:
                    self.sim.spawn_food()
                
            elif event.type == MOUSEBUTTONDOWN:
                # Overlay metrics handler
                if event.button == 1:
                    self.handle_boid_selection(mouse_pos)
                    self.handle_overlay_drag_start(mouse_pos)

                # Check main buttons
                if not self.spawn_dropdown_active:
                    for btn_id, _, rect in self.buttons:
                        if rect.collidepoint(mouse_pos):
                            self.handle_button_click(btn_id)
                else:
                    # Handle spawn dropdown interaction
                    if hasattr(self, 'prey_btn_rect') and self.prey_btn_rect.collidepoint(mouse_pos):
                        self.spawn_boids('prey')
                    elif hasattr(self, 'pred_btn_rect') and self.pred_btn_rect.collidepoint(mouse_pos):
                        self.spawn_boids('predator') 
                    elif hasattr(self, 'input_rect') and self.input_rect.collidepoint(mouse_pos):
                        self.handle_input_click()
                    elif not self.spawn_dropdown_rect.collidepoint(mouse_pos):
                        self.spawn_dropdown_active = False
                        
            elif event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    if self.spawn_dropdown_active:
                        self.spawn_dropdown_active = False
                    else:
                        self.running = False
                elif event.key == K_p:
                    self.toggle_pause()
                # Handle number keys for spawn amount when input is active
                elif hasattr(self, 'input_active') and self.input_active:
                    self.handle_key_input(event)
            
            elif event.type == MOUSEBUTTONUP:
                if event.button == 1:
                    self.is_dragging_overlay = False
            
            elif event.type == MOUSEMOTION:
                self.handle_overlay_drag(mouse_pos)
    
    def handle_boid_selection(self, mouse_pos):
        if not self.is_overlay_clicked(mouse_pos):
            self.selected_boid = None
        
        screen_x, screen_y = mouse_pos
        sim_y = screen_y - self.sim_area_top

        for boid in self.sim.prey + self.sim.predators:
            boid_screen_y = boid.y + self.sim_area_top
            distance = math.hypot(boid.x - screen_x, boid_screen_y - screen_y)
            if distance < 25:
                self.selected_boid = boid
                self.overlay_position = (screen_x + 20, screen_y + 20)
                break
    
    def handle_overlay_drag_start(self, mouse_pos):
        if self.selected_boid and self.is_titlebar_clicked(mouse_pos):
            self.is_dragging_overlay = True
            self.drag_offset = (mouse_pos[0] - self.overlay_position[0],
                                   mouse_pos[1] - self.overlay_position[1])
    
    def handle_overlay_drag(self, mouse_pos):
        if self.is_dragging_overlay:
            new_x = mouse_pos[0] - self.drag_offset[0]
            new_y = mouse_pos[1] - self.drag_offset[1]

            new_x = max(0, min(new_x, self.screen_width - 200))
            new_y = max(0, min(new_y, self.screen_height - 150))
            self.overlay_position = (new_x, new_y)

    def draw_boid_overlay(self):
        if not self.selected_boid:
            return
        
        overlay_width = 200
        overlay_height = 150
        x, y = self.overlay_position

        # Main overlay
        overlay_rect = pygame.Rect(x, y, overlay_width, overlay_height)
        pygame.draw.rect(self.screen, (40, 40, 50), overlay_rect)
        pygame.draw.rect(self.screen, (80, 80, 90), overlay_rect, 2)

        # Title bar
        title_rect = pygame.Rect(x, y, overlay_width, 25)
        pygame.draw.rect(self.screen, (60, 60, 70), title_rect)

        # Boid type
        boid_type = "Predator" if isinstance(self.selected_boid, Predator) else "Prey"
        title_text = self.small_font.render(f"{boid_type} Info", True, (255, 255, 255))
        self.screen.blit(title_text, (x + 10, y + 5))

        # Metrics
        speed = math.hypot(self.selected_boid.vel_x, self.selected_boid.vel_y)
        y_offset = 35
        metrics = [
            f"Speed: {speed:.1f} px/s",
            f"Hunger: {self.selected_boid.hunger:.1f}%",
            f"Health: {self.selected_boid.health:.1f}%",
            f"Children: {self.selected_boid.children_count}"
        ]

        if isinstance(self.selected_boid, Predator):
            metrics.append(f"KDA: {self.selected_boid.kda}")

        for metric in metrics:
            text_surf = self.small_font.render(metric, True, (220, 220, 220))
            self.screen.blit(text_surf, (x + 10, y + y_offset))
            y_offset += 20

    def is_titlebar_clicked(self, mouse_pos):
        if not self.selected_boid:
            return False
        x, y = self.overlay_position
        title_rect = pygame.Rect(x, y, 200, 25)
        return title_rect.collidepoint(mouse_pos)

    def is_overlay_clicked(self, mouse_pos):
        if not self.selected_boid:
            return False
        x, y = self.overlay_position
        overlay_rect = pygame.Rect(x, y, 200, 150)
        return overlay_rect.collidepoint(mouse_pos)

    def spawn_boids(self, boid_type):
        """
        Spawn the specified number of boids
        """
        try:
            # Get spawn amount
            amount = int(self.spawn_amount)
            
            # Limit to maximum (max set in sim) total and check current limits
            amount = max(1, min(amount, self.sim.max_prey + self.sim.max_predators))
            
            # Check if spawning would exceed limits
            if boid_type == 'prey' and len(self.sim.prey) + amount > self.sim.max_prey:
                amount = max(0, self.sim.max_prey - len(self.sim.prey))
                self.config_manager.log_info(f"Limited to {amount} prey (max: {self.sim.max_prey})")
                
            elif boid_type == 'predator' and len(self.sim.predators) + amount > self.sim.max_predators:
                amount = max(0, self.sim.max_predators - len(self.sim.predators))
                self.config_manager.log_info(f"Limited to {amount} predators (max: {self.sim.max_predators})")
            
            # Spawn the boids
            for _ in range(amount):
                self.sim.spawn_boid(boid_type)
                
            # Close dropdown after spawning
            self.spawn_dropdown_active = False
            self.input_active = False

            self.config_manager.log_info(f"Spawned {amount} {boid_type}")
            
        except Exception as e:
            self.config_manager.log_info(f"Failed to spawn {boid_type}")

    def handle_key_input(self, event):
        """
        Handle keyboard input for the amount field
        """
        if not hasattr(self, 'spawn_amount'):
            self.spawn_amount = ""
            
        if event.key == K_BACKSPACE:
            self.spawn_amount = self.spawn_amount[:-1]
        elif event.key == K_RETURN:
            self.input_active = False
        elif event.key >= 48 and event.key <= 57:  # Number keys 0-9
            if len(self.spawn_amount) < 2:  # Limit to 2 digits (max 99)
                self.spawn_amount += event.unicode
    
    def handle_input_click(self):
        """
        Handle click on the input field
        """
        self.input_active = True
        if not hasattr(self, 'spawn_amount'):
            self.spawn_amount = ""

    def draw_pause_notification(self):
        """
        Draw a pause notification overlay
        """
        # Create and draw pause text
        pause_text = self.font.render("SIM PAUSED", True, (255, 255, 255))
        text_rect = pause_text.get_rect(topright=(self.screen_width - 50, 15))
        self.screen.blit(pause_text, text_rect)

    def handle_button_click(self, btn_id):
        """
        Handle button click events
        """     
        if btn_id == 'spawn':
            # Toggle dropdown visibility
            self.spawn_dropdown_active = not self.spawn_dropdown_active
            # Initialize spawn amount
            if not hasattr(self, 'spawn_amount'):
                self.spawn_amount = "1"
        elif btn_id == 'pause':
            self.toggle_pause()
        elif btn_id == 'reset':
            self.config_manager.log_info("User clicked Reset button")
            self.sim.reset()
        elif btn_id == 'save':
            self.save_state()
        elif btn_id == 'load':
            self.load_state()

    def toggle_pause(self):
        self.sim.is_paused = not self.sim.is_paused
        self.config_manager.log_info(f"Simulation {'paused' if self.sim.is_paused else 'resumed'}")

    def save_state(self):
        """
        Handle save state with Tkinter
        """
        try:
            self.toggle_pause() # Pause
            
            root = Tk()
            root.withdraw()
            state = self.sim.save_state()
            success = self.config_manager.save_config(state)
            root.destroy()
            
            self.toggle_pause() # Resume
            
            if not success:
                tk.messagebox.showerror("Save Error", "Save failed. Please check file permissions or disk availability and try again")
        except Exception as e:
            error_msg = f"Save failed. Please check file permissions or disk availability and try again. Error: {str(e)}"
            tk.messagebox.showerror("Save Error", error_msg)
            self.config_manager.log_error(error_msg)
            # Ensure simulation is unpaused if error occurred
            self.toggle_pause()


    def load_state(self):
        """
        Handle load state with Tkinter
        """
        try:
            root = Tk()
            root.withdraw()
            state, error_msg = self.config_manager.load_config()
            root.destroy()
            
            if error_msg:
                tk.messagebox.showerror("Load Error", "Load failed. Select a valid file")
                return
            
            if state:
                self.sim.load_state(state)
                self.config_manager.log_info("Simulation state loaded successfully")
            elif state is not None:  # Empty but valid file
                tk.messagebox.showinfo("Load Info", "Selected configuration file is empty")
        except Exception as e:
            error_msg = f"Load failed. Select a valid file. Error: {str(e)}"
            tk.messagebox.showerror("Load Error", error_msg)
            self.config_manager.log_error(error_msg)
        
    def run(self):
        """
        Main loop
        """
        # Title screen setup
        button_width = 200
        button_height = 50
        start_x = (self.screen_width - button_width) // 2
        start_y = 200
        spacing = 60

        self.title_buttons = [
            {'id': 'start', 'rect': pygame.Rect(start_x, start_y, button_width, button_height), 'text': 'Start Sim'},
            {'id': 'load', 'rect': pygame.Rect(start_x, start_y + spacing, button_width, button_height), 'text': 'Load'},
            {'id': 'exit', 'rect': pygame.Rect(start_x, start_y + 2*spacing, button_width, button_height), 'text': 'Exit'}
        ]
        in_title_screen = True

         # Title screen loop
        while self.running and in_title_screen:
            for event in pygame.event.get():
                if event.type == QUIT:
                    self.running = False
                elif event.type == MOUSEBUTTONDOWN and event.button == 1:
                    mouse_pos = pygame.mouse.get_pos()
                    for btn in self.title_buttons:
                        if btn['rect'].collidepoint(mouse_pos):
                            if btn['id'] == 'start':
                                in_title_screen = False
                            elif btn['id'] == 'load':
                                self.load_state()
                                in_title_screen = False
                            elif btn['id'] == 'exit':
                                self.running = False

            # Draw title screen
            self.screen.fill((0, 0, 0))  # Black background

            # Draw title text
            title_font = pygame.font.Font(None, 72)
            title_text = title_font.render("Aquarium Simulator", True, (255, 255, 255))
            title_rect = title_text.get_rect(center=(self.screen_width//2, 100))
            self.screen.blit(title_text, title_rect)

            # Draw buttons
            button_font = pygame.font.Font(None, 36)
            for btn in self.title_buttons:
                color = (0, 100, 200) if btn['id'] != 'exit' else (200, 50, 50)
                pygame.draw.rect(self.screen, color, btn['rect'])
                text_surf = button_font.render(btn['text'], True, (255, 255, 255))
                text_rect = text_surf.get_rect(center=btn['rect'].center)
                self.screen.blit(text_surf, text_rect)

            pygame.display.flip()
            self.clock.tick(60)
        
        # Main sim
        if self.running:
            while self.running:
                delta_time = self.clock.tick(60) / 1000.0  # Delta time in seconds
                self.handle_input()

                if not self.sim.is_paused:
                    self.sim.update()
                    self.sim.food_items = [f for f in self.sim.food_items if not f.decay(delta_time)]
                
                self.draw_ui()
                self.draw_obstacles()
                self.draw_food()
                
                for boid in self.sim.prey + self.sim.predators:
                    self.draw_boid(boid)

                self.draw_boid_overlay()
                
                if self.sim.is_paused:
                    self.draw_pause_notification()

                # Draw spawn dropdown regardless of pause state
                if self.spawn_dropdown_active:
                    self.draw_spawn_dropdown()

                pygame.display.flip()
                self.clock.tick(60)  # Cap FPS


        pygame.quit()