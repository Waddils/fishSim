class Obstacle:
    def __init__(self, x, y, radius):
        try:
            self.x = float(x)
            self.y = float(y)
            self.radius = float(radius)
            if self.radius <= 0:
                raise ValueError("Radius must be positive")
        except (ValueError, TypeError) as e:
            raise Exception(f"Invalid parameters for Obstacle creation: {str(e)}")

    def contains(self, point_x, point_y):
        """
        Check if a point is inside the obstacle
        """
        try:
            """
            Essentially the following:
            d_dx = point_x - self.x
            d_dy = point_y - self.y
            d_distanceSq = (d_dx * d_dx) + (d_dy * d_dy)
            d_radiusSq = radius * radius
            return true if d_distanceSq <= d_radiusSq else false
            """
            return (point_x - self.x)**2 + (point_y - self.y)**2 <= self.radius**2
        except Exception as e:
            raise Exception(f"Failed to check if point is in obstacle: {str(e)}")