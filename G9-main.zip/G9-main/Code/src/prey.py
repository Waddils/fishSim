"""
Prey inherits from boid class for movement
"""

from boid import Boid
from config_manager import Config_Manager
import math

class Prey(Boid):
    def __init__(self, x, y, vel_x, vel_y):
        super().__init__(x, y, vel_x, vel_y)
        self.hunger = 94.0  # Start with less than reproduction rate (>95)
        self.health = 100.0
        self.reproduction_chance = 0.3 # 30% chance
        self.children_count = 0 # Number of children spawned

        # Prey eaten by predators
        self.is_being_eaten = False
        self.eaten_scale = 1.0  # 1.0 = normal size, 0.0 = fully shrunk
        self.shrink_speed = 0.15  # Shrink 15% per frame

        # Adjusting flocking parameters
        self.alignment_weight = 0.8 # was 1.2
        self.cohesion_weight = 1.0 # was 1.5
        self.separation_weight = 1.6 # was 1.2
        self.max_speed = 5.0 # was 3.8
        self.neighbor_radius = 60 # was 70
        self.separation_radius = 28 # was 25

        self.independence_factor = 0.6
        self.force_smoothing = 0.25
        
        # Predator avoidance parameters
        self.predator_detection_radius = 60  # Pixels
        self.predator_avoidance_weight = 2.0  # Strong priority
        
        # Obstacle hiding parameters
        self.hiding_weight = 1.8
        self.hiding_distance = 15  # Distance to stay behind obstacles when hiding

        # Config manager to log necessary actions
        self.config_manager = Config_Manager()
        
    def avoid_predators(self, predators):
        """
        Calculate steering force to avoid nearby predators
        """
        if not predators:
            return (0, 0)
            
        steering_x = 0
        steering_y = 0
        
        # Find nearby predators
        nearby_predators = []
        for predator in predators:
            distance = self.distance_to(predator)
            if distance < self.predator_detection_radius:
                nearby_predators.append((predator, distance))
        
        if not nearby_predators:
            return (0, 0)
            
        # Calculate avoidance vector
        for predator, distance in nearby_predators:
            # Vector away from predator
            diff_x = self.x - predator.x
            diff_y = self.y - predator.y
            
            # Normalize
            if distance > 0:  # Avoid division by zero
                diff_x /= distance
                diff_y /= distance
                
                # Closer predators have stronger effect (inverse proportion)
                weight = 1.0 - (distance / self.predator_detection_radius)
                weight = weight ** 2  # Square to make effect stronger when closer

                diff_x *= weight * self.max_speed
                diff_y *= weight * self.max_speed
                
                steering_x += diff_x
                steering_y += diff_y
        
        # Scale and apply inertia
        steering_x *= self.predator_avoidance_weight
        steering_y *= self.predator_avoidance_weight
        
        return self.limit_force((steering_x, steering_y), self.max_force * 2)  # Allow stronger force for predator avoidance
    
    def hide_behind_obstacles(self, obstacles, predators):
        """
        Find hiding spots behind obstacles when predators are nearby
        """
        if not obstacles or not predators:
            return (0, 0)
            
        # Find nearest predator
        nearest_predator = None
        nearest_distance = float('inf')
        
        for predator in predators:
            distance = self.distance_to(predator)
            if distance < self.predator_detection_radius and distance < nearest_distance:
                nearest_predator = predator
                nearest_distance = distance
                
        if not nearest_predator:
            return (0, 0)
            
        # Find best hiding spot
        best_hiding_spot = None
        best_score = float('inf')  # Lower is better
        
        for obstacle in obstacles:
            # Calculate vector from predator to obstacle
            obstacle_to_predator_x = obstacle.x - nearest_predator.x
            obstacle_to_predator_y = obstacle.y - nearest_predator.y
            distance_predator_to_obstacle = math.sqrt(obstacle_to_predator_x**2 + obstacle_to_predator_y**2)
            
            if distance_predator_to_obstacle == 0:
                continue
                
            # Normalize the vector
            obstacle_to_predator_x /= distance_predator_to_obstacle
            obstacle_to_predator_y /= distance_predator_to_obstacle
            
            # Calculate hiding position (behind obstacle from predator's perspective)
            hiding_pos_x = obstacle.x + obstacle_to_predator_x * (obstacle.radius + self.hiding_distance)
            hiding_pos_y = obstacle.y + obstacle_to_predator_y * (obstacle.radius + self.hiding_distance)
            
            # Calculate how good this hiding spot is
            distance_to_hiding = math.sqrt((hiding_pos_x - self.x)**2 + (hiding_pos_y - self.y)**2)
            distance_predator_to_hiding = math.sqrt((hiding_pos_x - nearest_predator.x)**2 + (hiding_pos_y - nearest_predator.y)**2)
            
            # Score is a combination of distance to hiding spot and how far hiding spot is from predator
            score = distance_to_hiding - distance_predator_to_hiding * 0.8
            
            if score < best_score:
                best_score = score
                best_hiding_spot = (hiding_pos_x, hiding_pos_y)
                
        if not best_hiding_spot:
            return (0, 0)
            
        # Calculate steering force towards hiding spot
        hiding_x, hiding_y = best_hiding_spot
        
        desired_x = hiding_x - self.x
        desired_y = hiding_y - self.y
        
        distance = math.sqrt(desired_x**2 + desired_y**2)
        if distance > 0:
            # Scale based on distance
            desired_x = (desired_x / distance) * self.max_speed
            desired_y = (desired_y / distance) * self.max_speed
            
            # Urgency based on predator proximity
            urgency = 1.0 - (nearest_distance / self.predator_detection_radius)
            desired_x *= urgency
            desired_y *= urgency
        
        # Calculate steering force
        steering_x = desired_x - self.vel_x
        steering_y = desired_y - self.vel_y
        
        # Apply hiding weight
        steering_x *= self.hiding_weight
        steering_y *= self.hiding_weight
        
        return self.limit_force((steering_x, steering_y), self.max_force * 1.5)
    
    def check_food_collision(self, food, radius=10):
        """
        Check if the prey is in the vicinity of a food object.
        """
        distance_squared = (self.x - food.x) ** 2 + (self.y - food.y) ** 2
        return distance_squared <= radius ** 2  # Check if prey is within the defined radius of the food

    
    def consume_food(self, food, food_items):
        """
        Consume the given food object and increase hunger.
        """
        self.hunger = min(100.0, self.hunger + 60.0)  # Increase hunger by 50, capped at 100
        # print(f"Prey at ({self.x}, {self.y}) consumed food at ({food.x}, {food.y}).")
        food_items.remove(food)  # Remove the food object from the simulation
        self.config_manager.log_info(f"Prey consumed food at ({food.x}, {food.y})")
        
    
    def seek_closest_food(self, food_items, smoothing_factor=0.2):
        """
        Steer the prey towards the closest food object with smoother movement.
        """
        closest_food = None
        closest_distance = float('inf')

        # Find the closest food object
        for food in food_items:
            distance = math.sqrt((self.x - food.x) ** 2 + (self.y - food.y) ** 2)
            if distance < closest_distance:
                closest_food = food
                closest_distance = distance

        if not closest_food:  # No food objects are available
            return (0, 0)

        # Calculate a vector towards the closest food
        desired_x = closest_food.x - self.x
        desired_y = closest_food.y - self.y
        distance = math.sqrt(desired_x**2 + desired_y**2)

        if distance > 0:
            # Normalize the vector and scale to max speed
            desired_x = (desired_x / distance) * self.max_speed
            desired_y = (desired_y / distance) * self.max_speed

        # Calculate the raw steering force
        steering_x = desired_x - self.vel_x
        steering_y = desired_y - self.vel_y

        # Apply smoothing for gradual turns
        steering_x = self.vel_x + (steering_x - self.vel_x) * smoothing_factor
        steering_y = self.vel_y + (steering_y - self.vel_y) * smoothing_factor

        return steering_x, steering_y