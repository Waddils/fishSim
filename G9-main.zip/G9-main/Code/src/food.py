import random

class Food:
    def __init__(self, x, y, size=5, decay_time=None):
        """
        Initializes a Food object
        """
        try:
            self.x = float(x)
            self.y = float(y)
            self.size = float(size)
            self.decay_time = decay_time if decay_time is not None else random.randint(10, 15)  # Random decay time

            if self.size <= 0:
                raise ValueError("Food size must be positive")
        except (ValueError, TypeError) as e:
            raise Exception(f"Invalid parameters for Food creation: {str(e)}")

    def collides_with_obstacle(self, obstacles):
        """
        Checks if the food overlaps with any obstacle.
        """
        try:
            buffer = 3 # Buffer to prevent food from spawning inside obstacles
            return any((self.x - obs.x) ** 2 + (self.y - obs.y) ** 2 <= (obs.radius + self.size + buffer) ** 2 for obs in obstacles)
        except Exception as e:
            raise Exception(f"Failed to check collision with obstacles: {str(e)}")

    @staticmethod
    def spawn_random(screen_width, screen_height, obstacles=None, food_size=5, boundary_top=0):
        """
        Spawns food at a random location that does not overlap with obstacles.
        """
        while True:
            x = random.randint(food_size, screen_width+50 - food_size)
            y = random.randint(boundary_top + food_size, screen_height+50 - food_size)
            food = Food(x, y, food_size)

            # Check for collision with obstacles if obstacles are provided
            if obstacles and food.collides_with_obstacle(obstacles):
                continue  # Skip invalid positions
            return food

    def decay(self, elapsed_time):
        """
        Simulates the decay of food over time.
        """
        self.decay_time -= elapsed_time
        if self.decay_time <= 0:
            return True
        return False