"""
Boid class for the Boids simulation.
"""

import math
import random
class Boid:
    def __init__(self, x, y, vel_x, vel_y):
        try:
            self.x = float(x)
            self.y = float(y)
            self.vel_x = float(vel_x)
            self.vel_y = float(vel_y)

            self.is_dead = False
            self.death_timer = .5 # visible after death
            
            # Flocking parameters
            self.max_speed = 3.0
            self.max_force = 0.8  # Maximum steering force was .5
            self.alignment_weight = 1.0
            self.cohesion_weight = 1.0
            self.separation_weight = 1.5
            self.obstacle_avoidance_weight = 2.0
            self.boundary_avoidance_weight = 2.5 # 1.8 -> 2.5
            self.neighbor_radius = 50  # Pixels
            self.separation_radius = 25  # Pixels - was 30
            self.obstacle_perception_radius = 40  # Pixels - was 50
            self.boundary_perception_distance = 50  # Distance to start avoiding boundaries
            self.inertia_factor = 0.75  # How much the previous velocity affects new velocity - was 0.9

            self.force_smoothing = 0.2 # Smooth force application
            self.independence_factor = 0.4 # 0=groupthink, 1=fully independent

            self.boundary_escape_bias = 0.4
        except (ValueError, TypeError) as e:
            raise Exception(f"Invalid parameters for Boid creation: {str(e)}")
    
    def update(self):
        """
        Updates the boid's position.
        """
        try:
            self.x += self.vel_x
            self.y += self.vel_y
        except Exception as e:
            raise Exception(f"Failed to update boid position: {str(e)}")

    def check_boundaries(self, screen_width, screen_height, boundary_top):
        try:
            steering_x = 0
            steering_y = 0
        
            # Reduced reaction distance for more natural behavior
            boundary_margin = 30
            max_avoid_force = 1.2 # 0.7 -> 1.2
        
            # Only react when actually close to edge (not just approaching)
            if self.x < boundary_margin:
                strength = (boundary_margin - self.x) / boundary_margin
                steering_x += strength * max_avoid_force
            elif self.x > screen_width - boundary_margin:
                strength = (self.x - (screen_width - boundary_margin)) / boundary_margin
                steering_x -= strength * max_avoid_force

            if self.y < boundary_top + boundary_margin:
                strength = (boundary_top + boundary_margin - self.y) / boundary_margin
                steering_y += strength * max_avoid_force
            elif self.y > screen_height - boundary_margin:
                strength = (self.y - (screen_height - boundary_margin)) / boundary_margin
                steering_y -= strength * max_avoid_force

            if steering_x != 0 or steering_y != 0:
                # Add forward momentum boost
                fwd_boost = 1.0 # 0.5 -> 1.0
                heading = math.atan2(self.vel_y, self.vel_x)
                steering_x += math.cos(heading) * fwd_boost
                steering_y += math.sin(heading) * fwd_boost
                
                self.vel_x += steering_x
                self.vel_y += steering_y
                self.limit_speed()
                
            # Hard boundary clamp
            self.x = max(10, min(self.x, screen_width - 10))
            self.y = max(boundary_top + 10, min(self.y, screen_height - 10))
            
        except Exception as e:
            raise Exception(f"Failed to check boundaries: {str(e)}")


    def avoid_obstacles(self, obstacles):
        try:
            steering_x = 0
            steering_y = 0
            obstacle_force_limit = 1.2  # Increased from 1.0
        
            # Reduced perception radius
            effective_radius = 40  # Down from 50
            min_escape_distance = 25  # New minimum distance to trigger avoidance
        
            for obstacle in obstacles:
                dx = obstacle.x - self.x
                dy = obstacle.y - self.y
                distance = math.sqrt(dx**2 + dy**2)
            
                if distance < effective_radius + obstacle.radius:
                    # Only react if obstacle is within critical range
                    if distance < (obstacle.radius + min_escape_distance):
                        # Calculate escape direction
                        escape_angle = math.atan2(-dy, -dx)
                        escape_x = math.cos(escape_angle) * obstacle_force_limit
                        escape_y = math.sin(escape_angle) * obstacle_force_limit
                    
                        # Add immediate escape force
                        steering_x += escape_x
                        steering_y += escape_y
                    
            if steering_x != 0 or steering_y != 0:
                # Apply with momentum preservation
                self.vel_x = self.vel_x * 0.8 + steering_x
                self.vel_y = self.vel_y * 0.8 + steering_y
                self.limit_speed()
            
            return (steering_x, steering_y)
        except Exception as e:
            raise Exception(f"Failed to process obstacle avoidance: {str(e)}")
    
    def resolve_collision(self, obstacles, buffer=2):
        """
        If the boid is inside any obstacle, push it out.
        The buffer is a small extra distance to ensure the boid is fully clear.
        """
        for obstacle in obstacles:
            if obstacle.contains(self.x, self.y):
                dx = self.x - obstacle.x
                dy = self.y - obstacle.y
                distance = math.hypot(dx, dy)
                desired_distance = obstacle.radius + buffer

                if distance == 0:  # Avoid division by zero
                    dx, dy = 1, 0
                    distance = 1
                    overlap = desired_distance
                else:
                    overlap = desired_distance - distance
                
                norm_dx = dx / distance
                norm_dy = dy / distance
                self.x += norm_dx * overlap
                self.y += norm_dy * overlap

    def distance_to(self, other):
        """
        Calculate distance to another boid
        """
        dx = self.x - other.x
        dy = self.y - other.y
        return math.sqrt(dx**2 + dy**2)

    def calculate_alignment(self, neighbors):
        """
        Steer towards average heading of neighbors
        """
        if not neighbors:
            return (0, 0)
        
        avg_vel_x = sum(b.vel_x for b in neighbors) / len(neighbors)
        avg_vel_y = sum(b.vel_y for b in neighbors) / len(neighbors)
        
        # Calculate steering force
        steering_x = avg_vel_x - self.vel_x
        steering_y = avg_vel_y - self.vel_y
        
        # Limit force
        return self.limit_force((steering_x, steering_y), self.max_force)

    def calculate_cohesion(self, neighbors):
        """
        Steer towards average position of neighbors
        """
        if not neighbors:
            return (0, 0)
        
        # Calculate center of mass
        avg_x = sum(b.x for b in neighbors) / len(neighbors)
        avg_y = sum(b.y for b in neighbors) / len(neighbors)
        
        # Vector towards center of mass
        desired_x = avg_x - self.x
        desired_y = avg_y - self.y
        
        # Scale to max speed
        magnitude = math.hypot(desired_x, desired_y)
        if magnitude > 0:
            desired_x = (desired_x / magnitude) * self.max_speed
            desired_y = (desired_y / magnitude) * self.max_speed
        
        # Calculate steering force
        steering_x = desired_x - self.vel_x
        steering_y = desired_y - self.vel_y
        
        # Limit force
        return self.limit_force((steering_x, steering_y), self.max_force)

    def calculate_separation(self, neighbors):
        """
        Steer away from nearby boids with distance-based scaling
        """
        close_neighbors = [b for b in neighbors if self.distance_to(b) < self.separation_radius]
        if not close_neighbors:
            return (0, 0)
        
        steering_x = 0
        steering_y = 0
        
        for neighbor in close_neighbors:
            # Vector away from neighbor
            diff_x = self.x - neighbor.x
            diff_y = self.y - neighbor.y
            
            # Weight by distance (closer = stronger)
            distance = self.distance_to(neighbor)
            if distance > 0:  # Avoid division by zero
                # Normalize and scale
                diff_x /= distance
                diff_y /= distance
                
                # Closer neighbors have stronger effect (inverse proportion)
                diff_x *= (self.separation_radius - distance) / self.separation_radius
                diff_y *= (self.separation_radius - distance) / self.separation_radius
                
                steering_x += diff_x
                steering_y += diff_y
        
        # Average
        if len(close_neighbors) > 0:
            steering_x /= len(close_neighbors)
            steering_y /= len(close_neighbors)
            
        # Scale to max speed
        magnitude = math.hypot(steering_x, steering_y)
        if magnitude > 0:
            steering_x = (steering_x / magnitude) * self.max_speed
            steering_y = (steering_y / magnitude) * self.max_speed
            
        # Calculate steering force
        steering_x -= self.vel_x
        steering_y -= self.vel_y
        
        # Limit force
        return self.limit_force((steering_x, steering_y), self.max_force)
    
    def apply_force(self, force_x, force_y, weight):
        """
        Apply forces with better balance of inertia and new forces
        """
        # Calculate force magnitude for threshold checking
        force_magnitude = math.sqrt(force_x**2 + force_y**2)
        
        if force_magnitude > 0.1:  # Only apply significant forces
            # Apply new force with more direct effect
            self.vel_x += force_x * weight * (self.force_smoothing * 2)
            self.vel_y += force_y * weight * (self.force_smoothing * 2)
        else:
            # For tiny forces, add minimal random movement
            self.vel_x += random.uniform(-0.1, 0.1)
            self.vel_y += random.uniform(-0.1, 0.1)
        
        # Preserve more of the current velocity (less damping)
        inertia = 0.95  # High inertia to maintain movement
        self.vel_x *= inertia
        self.vel_y *= inertia

    def limit_force(self, force, max_force):
        """
        Limit the magnitude of a steering force
        """
        fx, fy = force
        magnitude = math.hypot(fx, fy)
        if magnitude > max_force:
            scale = max_force / magnitude
            return (fx * scale, fy * scale)
        return force
    
    def limit_speed(self):
        """
        Limit the speed to max_speed
        """
        speed = math.hypot(self.vel_x, self.vel_y)
        if speed > self.max_speed:
            factor = self.max_speed / speed
            self.vel_x *= factor
            self.vel_y *= factor